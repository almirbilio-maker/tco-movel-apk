import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';

export default function ModalInfracao({ open, onOpenChange, infração, onSalvar, isLoading }) {
  const [formData, setFormData] = useState({
    diploma_legal: '',
    artigo: '',
    descricao: '',
    pena_minima: '',
    pena_maxima: '',
    classificacao: 'Crime MP0',
    palavras_chave: '',
    observacao: '',
    status: 'vigente'
  });

  const [erros, setErros] = useState({});

  useEffect(() => {
    if (infração) {
      setFormData({
        diploma_legal: infração.diploma_legal || '',
        artigo: infração.artigo || '',
        descricao: infração.descricao || '',
        pena_minima: infração.pena_minima || '',
        pena_maxima: infração.pena_maxima || '',
        classificacao: infração.classificacao || 'Crime MP0',
        palavras_chave: (infração.palavras_chave || []).join(', '),
        observacao: infração.observacao || '',
        status: infração.status || 'vigente'
      });
    } else {
      setFormData({
        diploma_legal: '',
        artigo: '',
        descricao: '',
        pena_minima: '',
        pena_maxima: '',
        classificacao: 'Crime MP0',
        palavras_chave: '',
        observacao: '',
        status: 'vigente'
      });
    }
    setErros({});
  }, [infração, open]);

  const validar = () => {
    const novosErros = {};
    if (!formData.diploma_legal.trim()) novosErros.diploma_legal = 'Diploma legal é obrigatório';
    if (!formData.artigo.trim()) novosErros.artigo = 'Artigo é obrigatório';
    if (!formData.descricao.trim()) novosErros.descricao = 'Descrição é obrigatória';
    if (!formData.pena_maxima.trim()) novosErros.pena_maxima = 'Pena máxima é obrigatória';
    setErros(novosErros);
    return Object.keys(novosErros).length === 0;
  };

  const handleSalvar = () => {
    if (!validar()) return;

    const dados = {
      ...formData,
      palavras_chave: formData.palavras_chave
        .split(',')
        .map((k) => k.trim())
        .filter((k) => k)
    };

    onSalvar(dados);
  };

  return (
    <AlertDialog open={open} onOpenChange={onOpenChange}>
      <AlertDialogContent className="max-w-md">
        <AlertDialogHeader>
          <AlertDialogTitle>
            {infração ? 'Editar Infração Penal' : 'Nova Infração Penal'}
          </AlertDialogTitle>
          <AlertDialogDescription className="text-xs">
            Preencha os dados da infração penal
          </AlertDialogDescription>
        </AlertDialogHeader>

        <div className="space-y-3 max-h-96 overflow-y-auto">
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="text-xs font-semibold text-gray-700 block mb-1">
                Diploma Legal *
              </label>
              <Input
                value={formData.diploma_legal}
                onChange={(e) => setFormData({ ...formData, diploma_legal: e.target.value })}
                placeholder="CP, CTB, LCP..."
                className="h-8 text-sm"
              />
              {erros.diploma_legal && (
                <p className="text-xs text-red-600 mt-0.5">{erros.diploma_legal}</p>
              )}
            </div>

            <div>
              <label className="text-xs font-semibold text-gray-700 block mb-1">
                Artigo *
              </label>
              <Input
                value={formData.artigo}
                onChange={(e) => setFormData({ ...formData, artigo: e.target.value })}
                placeholder="Ex: 147, 162..."
                className="h-8 text-sm"
              />
              {erros.artigo && (
                <p className="text-xs text-red-600 mt-0.5">{erros.artigo}</p>
              )}
            </div>
          </div>

          <div>
            <label className="text-xs font-semibold text-gray-700 block mb-1">
              Descrição *
            </label>
            <Input
              value={formData.descricao}
              onChange={(e) => setFormData({ ...formData, descricao: e.target.value })}
              placeholder="Descrição da infração..."
              className="h-8 text-sm"
            />
            {erros.descricao && (
              <p className="text-xs text-red-600 mt-0.5">{erros.descricao}</p>
            )}
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="text-xs font-semibold text-gray-700 block mb-1">
                Pena Mínima
              </label>
              <Input
                value={formData.pena_minima}
                onChange={(e) => setFormData({ ...formData, pena_minima: e.target.value })}
                placeholder="Ex: 1 mês"
                className="h-8 text-sm"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-gray-700 block mb-1">
                Pena Máxima *
              </label>
              <Input
                value={formData.pena_maxima}
                onChange={(e) => setFormData({ ...formData, pena_maxima: e.target.value })}
                placeholder="Ex: 2 anos"
                className="h-8 text-sm"
              />
              {erros.pena_maxima && (
                <p className="text-xs text-red-600 mt-0.5">{erros.pena_maxima}</p>
              )}
            </div>
          </div>

          <div>
            <label className="text-xs font-semibold text-gray-700 block mb-1">
              Classificação
            </label>
            <select
              value={formData.classificacao}
              onChange={(e) => setFormData({ ...formData, classificacao: e.target.value })}
              className="w-full border border-gray-300 rounded-md px-2 py-1.5 text-sm h-8"
            >
              <option value="Crime MP0">Crime MP0</option>
              <option value="Contravenção">Contravenção</option>
            </select>
          </div>

          <div>
            <label className="text-xs font-semibold text-gray-700 block mb-1">
              Palavras-chave
            </label>
            <Input
              value={formData.palavras_chave}
              onChange={(e) => setFormData({ ...formData, palavras_chave: e.target.value })}
              placeholder="Separadas por vírgula..."
              className="h-8 text-sm"
            />
          </div>

          <div>
            <label className="text-xs font-semibold text-gray-700 block mb-1">
              Observações
            </label>
            <Textarea
              value={formData.observacao}
              onChange={(e) => setFormData({ ...formData, observacao: e.target.value })}
              placeholder="Observações sobre a infração..."
              className="text-sm h-16 resize-none"
            />
          </div>

          <div>
            <label className="text-xs font-semibold text-gray-700 block mb-1">
              Status
            </label>
            <select
              value={formData.status}
              onChange={(e) => setFormData({ ...formData, status: e.target.value })}
              className="w-full border border-gray-300 rounded-md px-2 py-1.5 text-sm h-8"
            >
              <option value="vigente">Vigente</option>
              <option value="revogado">Revogado</option>
            </select>
          </div>
        </div>

        <div className="flex gap-2 justify-end pt-2">
          <AlertDialogCancel asChild>
            <Button variant="outline" size="sm">
              Cancelar
            </Button>
          </AlertDialogCancel>
          <AlertDialogAction asChild>
            <Button
              onClick={handleSalvar}
              disabled={isLoading}
              size="sm"
              className="bg-blue-600 hover:bg-blue-700 text-white"
            >
              {isLoading ? 'Salvando...' : 'Salvar'}
            </Button>
          </AlertDialogAction>
        </div>
      </AlertDialogContent>
    </AlertDialog>
  );
}