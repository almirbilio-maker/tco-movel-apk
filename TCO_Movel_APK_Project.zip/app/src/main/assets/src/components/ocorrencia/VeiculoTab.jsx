import React from 'react';
import { InputValidado } from '@/components/ui/input-validado';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { formatarPlaca, validarPlaca, formatarMarcaModelo } from '@/components/utils/validacoes';

export default function VeiculoTab({ veiculo = {}, onChange }) {
  const handleChange = (campo, valor) => {
    onChange({ ...veiculo, [campo]: valor });
  };

  return (
    <div className="space-y-4 p-4 pb-24">
      <div>
         <Label htmlFor="marca_modelo" className="text-gray-700 font-semibold">Marca/Modelo</Label>
         <Input
           id="marca_modelo"
           value={veiculo.marca_modelo || ''}
           onChange={(e) => handleChange('marca_modelo', e.target.value)}
           onBlur={(e) => handleChange('marca_modelo', formatarMarcaModelo(e.target.value))}
           placeholder="Ex: Volkswagen Gol"
           className="mt-1"
           autoComplete="off"
           autoCapitalize="words"
           autoCorrect="on"
         />
       </div>

      <div>
        <Label htmlFor="cor" className="text-gray-700 font-semibold">Cor</Label>
        <Input
          id="cor"
          value={veiculo.cor || ''}
          onChange={(e) => handleChange('cor', e.target.value)}
          onBlur={(e) => handleChange('cor', formatarNome(e.target.value))}
          placeholder="Ex: Branco"
          className="mt-1"
          autoComplete="off"
          autoCapitalize="words"
          autoCorrect="on"
        />
      </div>

      <InputValidado
        label="Placa"
        value={veiculo.placa || ''}
        onChange={(valor) => handleChange('placa', valor)}
        formatacao={formatarPlaca}
        validacao={validarPlaca}
        mensagemErro="Placa inválida (use ABC1234 ou ABC1D23)"
        placeholder="Ex: ABC1D23"
        maxLength={7}
        inputMode="text"
        className="uppercase"
      />
    </div>
  );
}