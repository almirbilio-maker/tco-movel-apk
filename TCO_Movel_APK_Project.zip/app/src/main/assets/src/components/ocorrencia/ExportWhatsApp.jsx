const formatarCPF = (cpf) => {
  if (!cpf) return '';
  const numeros = cpf.replace(/\D/g, '');
  if (numeros.length !== 11) return cpf;
  return numeros.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4');
};

export const exportarParaWhatsApp = (ocorrencia) => {
  let texto = `*TCO Nº ${ocorrencia.numero || 'S/N'}*\n\n`;
  
  texto += `📍 *Local:* ${ocorrencia.local}\n`;
  texto += `📅 *Data de Lavratura:* ${new Date(ocorrencia.data_lavratura).toLocaleDateString('pt-BR')}\n`;
  texto += `🏛️ *Comarca:* ${ocorrencia.comarca}\n\n`;
  
  texto += `*👤 DADOS DO AUTOR*\n`;
  texto += `Nome: ${ocorrencia.nome_autor}\n`;
  texto += `CPF: ${formatarCPF(ocorrencia.cpf_autor)}\n`;
  texto += `Telefone: ${ocorrencia.telefone_autor || 'Não informado'}\n`;
  texto += `Naturalidade: ${ocorrencia.naturalidade_autor || 'Não informado'}\n`;
  texto += `Nacionalidade: ${ocorrencia.nacionalidade_autor || 'Não informado'}\n`;
  texto += `Sexo: ${ocorrencia.sexo_autor || 'Não informado'}\n`;
  texto += `Data de Nascimento: ${ocorrencia.data_nascimento_autor ? new Date(ocorrencia.data_nascimento_autor).toLocaleDateString('pt-BR') : 'Não informado'}\n`;
  texto += `Estado Civil: ${ocorrencia.estado_civil_autor || 'Não informado'}\n`;
  texto += `Profissão: ${ocorrencia.profissao_autor || 'Não informado'}\n`;
  texto += `Escolaridade: ${ocorrencia.escolaridade_autor || 'Não informado'}\n`;
  texto += `Etnia: ${ocorrencia.etnia_autor || 'Não informado'}\n`;
  texto += `Identidade de Gênero: ${ocorrencia.identidade_genero_autor || 'Não informado'}\n`;
  texto += `Orientação Sexual: ${ocorrencia.orientacao_sexual_autor || 'Não informado'}\n\n`;
  
  texto += `*📍 ENDEREÇO DO AUTOR*\n`;
  texto += `Logradouro: ${ocorrencia.logradouro_autor || 'Não informado'}\n`;
  texto += `Número: ${ocorrencia.numero_endereco_autor || 'Não informado'}\n`;
  texto += `Bairro: ${ocorrencia.bairro_autor || 'Não informado'}\n`;
  texto += `Ponto de Referência: ${ocorrencia.ponto_referencia_autor || 'Não informado'}\n`;
  texto += `Município: ${ocorrencia.municipio_autor || 'Não informado'}\n\n`;
  
  texto += `*📝 DECLARAÇÃO DO AUTOR*\n`;
  texto += `${ocorrencia.declaracao_autor}\n\n`;
  
  texto += `*✅ COMPROMISSOS*\n`;
  texto += `Aceita comunicação eletrônica: ${ocorrencia.aceita_comunicacao ? 'Sim' : 'Não'}\n`;
  texto += `Deseja Defensoria Pública: ${ocorrencia.deseja_defensoria ? 'Sim' : 'Não'}\n\n`;
  
  if (ocorrencia.tem_testemunha) {
    texto += `*👥 DADOS DA TESTEMUNHA*\n`;
    texto += `Nome: ${ocorrencia.nome_testemunha}\n`;
    texto += `CPF: ${formatarCPF(ocorrencia.cpf_testemunha)}\n`;
    texto += `Telefone: ${ocorrencia.telefone_testemunha || 'Não informado'}\n`;
    texto += `Naturalidade: ${ocorrencia.naturalidade_testemunha || 'Não informado'}\n`;
    texto += `Nacionalidade: ${ocorrencia.nacionalidade_testemunha || 'Não informado'}\n`;
    texto += `Sexo: ${ocorrencia.sexo_testemunha || 'Não informado'}\n`;
    texto += `Data de Nascimento: ${ocorrencia.data_nascimento_testemunha ? new Date(ocorrencia.data_nascimento_testemunha).toLocaleDateString('pt-BR') : 'Não informado'}\n`;
    texto += `Estado Civil: ${ocorrencia.estado_civil_testemunha || 'Não informado'}\n`;
    texto += `Profissão: ${ocorrencia.profissao_testemunha || 'Não informado'}\n`;
    texto += `Escolaridade: ${ocorrencia.escolaridade_testemunha || 'Não informado'}\n`;
    texto += `Etnia: ${ocorrencia.etnia_testemunha || 'Não informado'}\n`;
    texto += `Identidade de Gênero: ${ocorrencia.identidade_genero_testemunha || 'Não informado'}\n`;
    texto += `Orientação Sexual: ${ocorrencia.orientacao_sexual_testemunha || 'Não informado'}\n\n`;
    
    texto += `*📍 ENDEREÇO DA TESTEMUNHA*\n`;
    texto += `Logradouro: ${ocorrencia.logradouro_testemunha || 'Não informado'}\n`;
    texto += `Número: ${ocorrencia.numero_endereco_testemunha || 'Não informado'}\n`;
    texto += `Bairro: ${ocorrencia.bairro_testemunha || 'Não informado'}\n`;
    texto += `Ponto de Referência: ${ocorrencia.ponto_referencia_testemunha || 'Não informado'}\n`;
    texto += `Município: ${ocorrencia.municipio_testemunha || 'Não informado'}\n\n`;
    
    texto += `*📝 DECLARAÇÃO DA TESTEMUNHA*\n`;
    texto += `${ocorrencia.declaracao_testemunha}\n\n`;
  }
  
  texto += `*👮 DADOS DO PRF*\n`;
  texto += `Nome: ${ocorrencia.nome_prf}\n`;
  texto += `Matrícula: ${ocorrencia.matricula}\n\n`;
  
  texto += `Status: ${ocorrencia.status === 'finalizado' ? 'Finalizado' : 'Rascunho'}\n`;

  // Copiar para clipboard
  navigator.clipboard.writeText(texto).then(() => {
    alert('Dados copiados para a área de transferência! Cole no WhatsApp.');
  }).catch(() => {
    // Fallback: criar elemento textarea para copiar
    const textarea = document.createElement('textarea');
    textarea.value = texto;
    document.body.appendChild(textarea);
    textarea.select();
    document.execCommand('copy');
    document.body.removeChild(textarea);
    alert('Dados copiados para a área de transferência! Cole no WhatsApp.');
  });
};