import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { FileText, Share2, Copy, CheckCircle } from 'lucide-react';
import jsPDF from 'jspdf';
import { extrairCidadeUF, formatarDataExtensoComLocal } from '@/components/utils/validacoes';

export default function ExportacaoTab({ ocorrencia }) {
  const [copiado, setCopiado] = useState(false);

  const gerarPDFs = async (tipo = 'todos') => {
    const numeroTCO = ocorrencia.numero_tco || 'SEM_NUMERO';
    
    // Função auxiliar para formatar data por extenso
    const formatarDataExtenso = (dataStr) => {
      if (!dataStr) return '';
      const meses = ['janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho', 
                     'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro'];
      const data = new Date(dataStr + 'T00:00:00');
      const dia = data.getDate();
      const mes = meses[data.getMonth()];
      const ano = data.getFullYear();
      return `${dia} de ${mes} de ${ano}`;
    };
    


    // Gerar PDFs individuais por envolvido seguindo formatação oficial
    if (ocorrencia.envolvidos && ocorrencia.envolvidos.length > 0) {
      for (const [index, envolvido] of ocorrencia.envolvidos.entries()) {
        
        // 1. TERMO DE COMPROMISSO (para Autores e Partícipes)
        if ((envolvido.condicao === 'Autor' || envolvido.condicao === 'Partícipe') && (tipo === 'todos' || tipo === 'tc')) {
          const docComp = new jsPDF();
          
          // Cabeçalho com logos (simulado)
          docComp.setFontSize(10);
          docComp.setFont('helvetica', 'normal');
          docComp.text('Ministério da Justiça', 20, 15);
          docComp.text('e Segurança Pública', 20, 20);
          docComp.text('PRF', 185, 18, { align: 'right' });
          
          docComp.setFontSize(28);
          docComp.setFont('helvetica', 'bold');
          docComp.text('TCO', 105, 35, { align: 'center' });
          
          docComp.setFontSize(13);
          docComp.setFont('helvetica', 'bold');
          docComp.text('Termo Circunstanciado de Ocorrência', 105, 43, { align: 'center' });
          
          docComp.setFontSize(11);
          docComp.setFont('helvetica', 'bold');
          docComp.text(`Nº ${numeroTCO}`, 105, 50, { align: 'center' });
          
          // Título em caixa
          docComp.setLineWidth(0.5);
          docComp.rect(15, 58, 180, 10);
          docComp.setFontSize(11);
          docComp.setFont('helvetica', 'bold');
          docComp.text('TERMO DE COMPROMISSO DE COMPARECIMENTO DO AUTOR', 105, 65, { align: 'center' });
          
          // Conteúdo
          let y = 75;
          docComp.setFontSize(10.5);
          docComp.setFont('helvetica', 'normal');
          
          const texto1 = `O Policial Rodoviário Federal ${ocorrencia.policial_responsavel || '___________________________'}, matrícula nº ${ocorrencia.matricula_policial || '___________'}, com fulcro na Lei 9.099/95, faz saber a ${envolvido.nome_completo || '__________________________________________________'}, portador(a) do CPF nº ${envolvido.cpf || '___________________________________'} que, nesta data, foi lavrado o presente Termo Circunstanciado de Ocorrência (TCO), em seu desfavor.`;
          
          const linhas1 = docComp.splitTextToSize(texto1, 170);
          docComp.text(linhas1, 20, y);
          y += linhas1.length * 5.5 + 6;
          
          const texto2 = `Por meio do presente instrumento o arrolado assume o COMPROMISSO DE COMPARECER ao Juizado Especial Criminal da Comarca de ${ocorrencia.comarca || '_________________________'}, em dia e hora a serem determinados posteriormente quando da intimação feita pelo referido juízo na forma da lei, na qualidade de autor(a) dos fatos.`;
          
          const linhas2 = docComp.splitTextToSize(texto2, 170);
          docComp.text(linhas2, 20, y);
          y += linhas2.length * 5.5 + 6;
          
          const texto3 = 'Fica ciente que o não comparecimento o sujeitará às medidas previstas na Lei nº 9.099/95, sem prejuízo das demais cominações legais pertinentes.';
          const linhas3 = docComp.splitTextToSize(texto3, 170);
          docComp.text(linhas3, 20, y);
          y += linhas3.length * 5.5 + 6;
          
          const texto4 = 'É obrigatório que o autor dos fatos se faça acompanhar de advogado por ocasião do comparecimento àquele Juizado.';
          const linhas4 = docComp.splitTextToSize(texto4, 170);
          docComp.text(linhas4, 20, y);
          y += linhas4.length * 5.5 + 6;
          
          const texto5 = 'Fica advertido que, na falta de um advogado, ser-lhe-á designado um defensor público, conforme disposto no art. 68 da supracitada lei.';
          const linhas5 = docComp.splitTextToSize(texto5, 170);
          docComp.text(linhas5, 20, y);
          y += linhas5.length * 5.5 + 8;
          
          docComp.setFont('helvetica', 'bold');
          docComp.text('O compromissado informa que:', 20, y);
          y += 8;
          
          docComp.setFont('helvetica', 'normal');
          
          // Checkbox comunicação eletrônica
          const checkComunicacao = envolvido.aceita_comunicacao_eletronica ? '( X )' : '(     )';
          const texto6 = `${checkComunicacao} Aceita receber comunicações referentes ao processo criminal por meio de mensagem eletrônica (SMS) e/ou via aplicativo de troca de mensagens, por meio do telefone celular de número: ${envolvido.telefone_celular || '_________________________________'}.`;
          const linhas6 = docComp.splitTextToSize(texto6, 165);
          docComp.text(linhas6, 20, y);
          y += linhas6.length * 5.5 + 5;
          
          // Checkbox defensoria
          const checkDefensoria = envolvido.deseja_assistencia_defensoria ? '( X )' : '(     )';
          docComp.text(`${checkDefensoria} Deseja receber assistência da Defensoria Pública.`, 20, y);
          y += 10;
          
          // Local e Data (apenas Cidade-UF)
          const localData = formatarDataExtensoComLocal(ocorrencia.data, ocorrencia.local);
          docComp.setFontSize(9);
          docComp.text(localData, 190, y, { align: 'right' });
          y += 18;
          
          // Assinaturas
          if (envolvido.assinatura_compromisso) {
            try {
              const response = await fetch(envolvido.assinatura_compromisso);
              const blob = await response.blob();
              const reader = new FileReader();
              await new Promise((resolve) => {
                reader.onloadend = () => {
                  const imgData = reader.result;
                  docComp.addImage(imgData, 'PNG', 75, y, 60, 20, undefined, 'NONE');
                  y += 22;
                  resolve();
                };
                reader.readAsDataURL(blob);
              });
            } catch (error) {
              console.error('Erro ao carregar assinatura:', error);
              y += 22;
            }
          }
          docComp.setFontSize(9);
          docComp.text('_________________________________________', 70, y);
          y += 5;
          docComp.setFont('helvetica', 'normal');
          docComp.text('Compromissado(a)', 105, y, { align: 'center' });
          y += 10;
          
          docComp.setFontSize(8);
          docComp.setFont('helvetica', 'italic');
          docComp.text('assinado eletronicamente', 105, y, { align: 'center' });
          y += 4;
          docComp.setFontSize(9);
          docComp.setFont('helvetica', 'normal');
          docComp.text('_________________________________________', 70, y);
          y += 5;
          docComp.text('Policial Rodoviário Federal', 105, y, { align: 'center' });
          
          const nomeArquivo = envolvido.nome_completo || `Envolvido_${index + 1}`;
          const prefixoTC = envolvido.condicao === 'Partícipe' ? 'TC - Partícipe' : 'TC Autor';
          docComp.save(`${prefixoTC} - ${nomeArquivo}.pdf`);
        }
        
        // 2. TERMO DE DECLARAÇÃO (para todos os envolvidos)
        if (tipo === 'todos' || tipo === 'tde') {
        const docDecl = new jsPDF();
        
        // Cabeçalho com logos (simulado)
        docDecl.setFontSize(10);
        docDecl.setFont('helvetica', 'normal');
        docDecl.text('Ministério da Justiça', 20, 15);
        docDecl.text('e Segurança Pública', 20, 20);
        docDecl.text('PRF', 185, 18, { align: 'right' });
        
        docDecl.setFontSize(28);
        docDecl.setFont('helvetica', 'bold');
        docDecl.text('TCO', 105, 35, { align: 'center' });
        
        docDecl.setFontSize(13);
        docDecl.setFont('helvetica', 'bold');
        docDecl.text('Termo Circunstanciado de Ocorrência', 105, 43, { align: 'center' });
        
        docDecl.setFontSize(11);
        docDecl.setFont('helvetica', 'bold');
        docDecl.text(`Nº ${numeroTCO}`, 105, 50, { align: 'center' });
        
        // Título em caixa
        docDecl.setLineWidth(0.5);
        docDecl.rect(15, 58, 180, 10);
        docDecl.setFontSize(12);
        docDecl.setFont('helvetica', 'bold');
        docDecl.text('Termo de Declaração de Envolvido', 105, 65, { align: 'center' });
        
        // Checkboxes de condição: Autor | Vítima | Testemunha (Partícipe marca Autor)
        let y = 83;
        docDecl.setFontSize(11);
        const checkSize = 4;
        const condicaoCheckbox = envolvido.condicao === 'Partícipe' ? 'Autor' : envolvido.condicao;

        docDecl.rect(20, y - 3.5, checkSize, checkSize);
        if (condicaoCheckbox === 'Autor') {
          docDecl.setFontSize(14); docDecl.text('X', 21, y); docDecl.setFontSize(11);
        }
        docDecl.text('Autor', 27, y);

        docDecl.rect(80, y - 3.5, checkSize, checkSize);
        if (condicaoCheckbox === 'Vítima') {
          docDecl.setFontSize(14); docDecl.text('X', 81, y); docDecl.setFontSize(11);
        }
        docDecl.text('Vítima', 87, y);

        docDecl.rect(140, y - 3.5, checkSize, checkSize);
        if (condicaoCheckbox === 'Testemunha') {
          docDecl.setFontSize(14); docDecl.text('X', 141, y); docDecl.setFontSize(11);
        }
        docDecl.text('Testemunha', 147, y);

        y += 14;
        
        // Conteúdo da declaração
        docDecl.setFontSize(10.5);
        docDecl.setFont('helvetica', 'normal');
        
        const prefixoDecl = `Eu, ${envolvido.nome_completo || '_____________________________________________'}, CPF ${envolvido.cpf || '_____________________'}, voluntariamente, declaro QUE `;
        
        // Primeira linha com o prefixo
        docDecl.text(prefixoDecl, 20, y, { maxWidth: 170 });
        
        // Calcular altura ocupada pela primeira linha
        const linhasPrefixo = docDecl.splitTextToSize(prefixoDecl, 170);
        const alturaPrefix = linhasPrefixo.length * 5.5;
        
        // Adicionar o texto da declaração logo após, na mesma linha se couber
        if (envolvido.declaracao && envolvido.declaracao.trim()) {
          const textoDeclaracao = envolvido.declaracao;
          const linhasDecl = docDecl.splitTextToSize(textoDeclaracao, 170);
          docDecl.text(linhasDecl, 20, y + alturaPrefix);
          y += alturaPrefix + linhasDecl.length * 5.5 + 15;
        } else {
          y += alturaPrefix + 15;
        }
        
        // Local e Data acima da assinatura (apenas Cidade-UF)
        const localDataDecl = formatarDataExtensoComLocal(ocorrencia.data, ocorrencia.local);
        docDecl.setFontSize(9);
        docDecl.text(localDataDecl, 190, y, { align: 'right' });
        y += 15;
        
        // Linha de assinatura com imagem
        if (envolvido.assinatura_declaracao) {
          try {
            const response = await fetch(envolvido.assinatura_declaracao);
            const blob = await response.blob();
            const reader = new FileReader();
            await new Promise((resolve) => {
              reader.onloadend = () => {
                const imgData = reader.result;
                docDecl.addImage(imgData, 'PNG', 75, y, 60, 20, undefined, 'NONE');
                y += 22;
                resolve();
              };
              reader.readAsDataURL(blob);
            });
          } catch (error) {
            console.error('Erro ao carregar assinatura:', error);
            y += 22;
          }
        }
        docDecl.setFontSize(9);
        docDecl.text('_______________________________________________________________', 55, y);
        y += 5;
        docDecl.text('Declarante', 105, y, { align: 'center' });
        
        const nomeArquivoDecl = envolvido.nome_completo || `Envolvido_${index + 1}`;
        const condicaoDecl = envolvido.condicao || 'Envolvido';
        const prefixoTDE = (condicaoDecl === 'Testemunha' || condicaoDecl === 'Partícipe')
          ? `TDE - ${condicaoDecl}`
          : `TDE ${condicaoDecl}`;
        docDecl.save(`${prefixoTDE} - ${nomeArquivoDecl}.pdf`);
        }
      }
    }
  };

  const gerarTextoCompartilhamento = () => {
    let texto = '━━━━━━━━━━━━━━━━━━━━━━\n';
    texto += '📋 OCORRÊNCIA TCO\n';
    texto += '━━━━━━━━━━━━━━━━━━━━━━\n\n';
    
    texto += `📍 *DADOS DA OCORRÊNCIA*\n`;
    texto += `Número TCO: ${ocorrencia.numero_tco || 'N/A'}\n`;
    texto += `Data: ${ocorrencia.data || 'N/A'}\n`;
    texto += `Local: ${ocorrencia.local || 'N/A'}\n`;
    texto += `Comarca: ${ocorrencia.comarca || 'N/A'}\n\n`;
    
    texto += `👮 *POLICIAL RESPONSÁVEL*\n`;
    texto += `Nome: ${ocorrencia.policial_responsavel || 'N/A'}\n`;
    texto += `Matrícula: ${ocorrencia.matricula_policial || 'N/A'}\n\n`;
    
    if (ocorrencia.veiculo && ocorrencia.veiculo.placa) {
      texto += `🚗 *VEÍCULO*\n`;
      texto += `Placa: ${ocorrencia.veiculo.placa || 'N/A'}\n`;
      texto += `Marca/Modelo: ${ocorrencia.veiculo.marca_modelo || 'N/A'}\n`;
      texto += `Cor: ${ocorrencia.veiculo.cor || 'N/A'}\n\n`;
    }
    
    if (ocorrencia.envolvidos && ocorrencia.envolvidos.length > 0) {
      texto += `👥 *ENVOLVIDOS*\n\n`;
      
      ocorrencia.envolvidos.forEach((envolvido, index) => {
        texto += `━━ ENVOLVIDO ${index + 1} ━━\n`;
        texto += `Condição: ${envolvido.condicao || 'N/A'}\n`;
        texto += `Nome: ${envolvido.nome_completo || 'N/A'}\n`;
        texto += `CPF: ${envolvido.cpf || 'N/A'}\n`;
        texto += `Telefone: ${envolvido.telefone_celular || 'N/A'}\n`;
        
        if (envolvido.data_nascimento) {
          texto += `Data Nasc.: ${envolvido.data_nascimento}\n`;
        }
        
        if (envolvido.endereco_logradouro) {
          texto += `Endereço: ${envolvido.endereco_logradouro}, ${envolvido.endereco_numero || 'S/N'}\n`;
          if (envolvido.endereco_bairro) {
            texto += `Bairro: ${envolvido.endereco_bairro}\n`;
          }
          if (envolvido.endereco_referencia) {
            texto += `Referência: ${envolvido.endereco_referencia}\n`;
          }
          if (envolvido.endereco_municipio) {
            texto += `Município: ${envolvido.endereco_municipio}\n`;
          }
        }
        
        // Dados complementares
        if (envolvido.naturalidade) {
          texto += `Naturalidade: ${envolvido.naturalidade}\n`;
        }
        if (envolvido.nacionalidade) {
          texto += `Nacionalidade: ${envolvido.nacionalidade}\n`;
        }
        if (envolvido.sexo) {
          texto += `Sexo: ${envolvido.sexo}\n`;
        }
        if (envolvido.estado_civil) {
          texto += `Estado Civil: ${envolvido.estado_civil}\n`;
        }
        if (envolvido.profissao) {
          texto += `Profissão: ${envolvido.profissao}\n`;
        }
        if (envolvido.escolaridade) {
          texto += `Escolaridade: ${envolvido.escolaridade}\n`;
        }
        if (envolvido.etnia) {
          texto += `Etnia: ${envolvido.etnia}\n`;
        }
        if (envolvido.identidade_genero) {
          texto += `Identidade de Gênero: ${envolvido.identidade_genero}\n`;
        }
        if (envolvido.orientacao_sexual) {
          texto += `Orientação Sexual: ${envolvido.orientacao_sexual}\n`;
        }
        
        // Declaração
        if (envolvido.declaracao) {
          texto += `\n📝 Declaração:\n${envolvido.declaracao}\n`;
        }
        
        // Informações adicionais para Autores
        if (envolvido.condicao === 'Autor') {
          texto += `\nAceita comunicação eletrônica: ${envolvido.aceita_comunicacao_eletronica ? 'Sim' : 'Não'}\n`;
          texto += `Deseja assistência da Defensoria: ${envolvido.deseja_assistencia_defensoria ? 'Sim' : 'Não'}\n`;
        }
        
        texto += `\n`;
      });
    }
    
    texto += '━━━━━━━━━━━━━━━━━━━━━━\n';
    texto += 'Documento gerado pelo TCO Móvel\n';
    
    navigator.clipboard.writeText(texto);
    setCopiado(true);
    setTimeout(() => setCopiado(false), 3000);
    
    if (navigator.share) {
      navigator.share({
        title: `TCO ${ocorrencia.numero_tco || 'SEM_NUMERO'}`,
        text: texto
      });
    }
  };

  return (
    <div className="space-y-4 p-4 pb-24">
      <Card className="bg-white/95 border-l-4 border-l-blue-900">
        <CardContent className="p-4 space-y-3">
          <div className="flex items-center gap-3 mb-2">
            <FileText className="w-6 h-6 text-blue-900" />
            <div>
              <h3 className="font-semibold text-blue-900">Exportar PDFs Individuais</h3>
              <p className="text-sm text-gray-600">
                TC para Autor + TDE para todos os envolvidos (condição selecionada automaticamente)
              </p>
            </div>
          </div>
          
          <div className="space-y-2">
            <Button
              onClick={() => gerarPDFs('todos')}
              className="w-full bg-blue-900 hover:bg-blue-800 text-yellow-400 py-5 font-semibold"
            >
              <FileText className="w-5 h-5 mr-2" />
              Gerar Todos os PDFs
            </Button>
            
            <Button
              onClick={() => gerarPDFs('tc')}
              className="w-full bg-blue-700 hover:bg-blue-600 text-white py-4"
            >
              <FileText className="w-5 h-5 mr-2" />
              Somente TC - Autor
            </Button>
            
            <Button
              onClick={() => gerarPDFs('tde')}
              className="w-full bg-blue-700 hover:bg-blue-600 text-white py-4"
            >
              <FileText className="w-5 h-5 mr-2" />
              Somente TDE - Envolvidos
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card className="bg-white/95 border-l-4 border-l-green-600">
        <CardContent className="p-4 space-y-3">
          <div className="flex items-center gap-3 mb-2">
            <Share2 className="w-6 h-6 text-green-600" />
            <div>
              <h3 className="font-semibold text-blue-900">Exportar em Texto</h3>
              <p className="text-sm text-gray-600">
                Copia texto formatado para WhatsApp e abre compartilhamento
              </p>
            </div>
          </div>
          
          <Button
            onClick={gerarTextoCompartilhamento}
            className="w-full bg-green-600 hover:bg-green-700 text-white py-5 font-semibold"
          >
            {copiado ? (
              <>
                <CheckCircle className="w-5 h-5 mr-2" />
                Copiado! Compartilhar
              </>
            ) : (
              <>
                <Copy className="w-5 h-5 mr-2" />
                Copiar e Compartilhar
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      <div className="text-xs text-gray-500 text-center mt-4">
        Os arquivos são gerados localmente no dispositivo
      </div>
    </div>
  );
}