import React from 'react';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { AlertTriangle } from 'lucide-react';

export default function ConfirmacaoExclusao({ open, onOpenChange, onConfirm, numeroTCO }) {
  return (
    <AlertDialog open={open} onOpenChange={onOpenChange}>
      <AlertDialogContent className="max-w-md">
        <AlertDialogHeader>
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 bg-red-100 rounded-full">
              <AlertTriangle className="w-6 h-6 text-red-600" />
            </div>
            <AlertDialogTitle className="text-xl">
              Confirmar exclusão da ocorrência?
            </AlertDialogTitle>
          </div>
          <AlertDialogDescription className="text-left space-y-3 pt-2">
            <p className="font-semibold text-gray-900">
              {numeroTCO && `TCO Nº ${numeroTCO}`}
            </p>
            <p className="text-gray-700">
              Esta ação removerá permanentemente:
            </p>
            <ul className="list-disc list-inside space-y-1 text-gray-600 ml-2">
              <li>Dados da ocorrência</li>
              <li>Envolvidos</li>
              <li>Veículos</li>
              <li>PDFs gerados</li>
              <li>Assinaturas capturadas</li>
            </ul>
            <p className="text-red-600 font-semibold pt-2">
              ⚠️ Esta ação não poderá ser desfeita.
            </p>
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter className="gap-2 sm:gap-2">
          <AlertDialogCancel className="flex-1">
            Cancelar
          </AlertDialogCancel>
          <AlertDialogAction
            onClick={onConfirm}
            className="flex-1 bg-red-600 hover:bg-red-700"
          >
            Confirmar Exclusão
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}