import React, { useRef, useState, useEffect } from 'react';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { X } from 'lucide-react';
import { base44 } from '@/api/base44Client';

function AssinaturaCanvas({ titulo, assinatura, onChange }) {
  const canvasRef = useRef(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const lastX = useRef(0);
  const lastY = useRef(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    
    if (assinatura) {
      const img = new Image();
      img.crossOrigin = 'anonymous';
      img.onload = () => {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      };
      img.onerror = () => console.error('Erro ao carregar imagem da assinatura');
      img.src = assinatura;
    } else {
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.strokeStyle = '#ccc';
      ctx.lineWidth = 1;
      ctx.setLineDash([5, 5]);
      ctx.strokeRect(10, 10, canvas.width - 20, canvas.height - 20);
      ctx.setLineDash([]);
    }
  }, [assinatura]);

  const setupCanvasContext = () => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    ctx.strokeStyle = '#1e293b';
    ctx.lineWidth = 2.5;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.globalCompositeOperation = 'source-over';
    return ctx;
  };

  const getCoordinates = (e) => {
    const canvas = canvasRef.current;
    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;
    
    const x = ((e.touches ? e.touches[0].clientX : e.clientX) - rect.left) * scaleX;
    const y = ((e.touches ? e.touches[0].clientY : e.clientY) - rect.top) * scaleY;
    return { x, y };
  };

  const startDrawing = (e) => {
    if (isUploading) return;
    e.preventDefault();
    setIsDrawing(true);
    
    const { x, y } = getCoordinates(e);
    lastX.current = x;
    lastY.current = y;
    
    const ctx = setupCanvasContext();
    ctx.beginPath();
    ctx.moveTo(x, y);
  };

  const draw = (e) => {
    if (!isDrawing || isUploading) return;
    e.preventDefault();
    
    const { x, y } = getCoordinates(e);
    const ctx = setupCanvasContext();
    
    ctx.beginPath();
    ctx.moveTo(lastX.current, lastY.current);
    ctx.lineTo(x, y);
    ctx.stroke();
    
    lastX.current = x;
    lastY.current = y;
  };

  const stopDrawing = () => {
    setIsDrawing(false);
  };

  const confirmarAssinatura = async () => {
    const canvas = canvasRef.current;

    setIsUploading(true);

    // Criar canvas temporário para remover fundo
    const tempCanvas = document.createElement('canvas');
    tempCanvas.width = canvas.width;
    tempCanvas.height = canvas.height;
    const tempCtx = tempCanvas.getContext('2d');

    // Obter dados da imagem
    const imageData = canvas.getContext('2d').getImageData(0, 0, canvas.width, canvas.height);
    const data = imageData.data;

    // Remover fundo branco/cinza: deixar apenas os pixels pretos da assinatura
    for (let i = 0; i < data.length; i += 4) {
      const r = data[i];
      const g = data[i + 1];
      const b = data[i + 2];
      const a = data[i + 3];

      // Se pixel é branco ou cinza claro (background), tornar transparente
      if ((r > 240 && g > 240 && b > 240) || (r > 200 && g > 200 && b > 200 && Math.abs(r - g) < 10 && Math.abs(g - b) < 10)) {
        data[i + 3] = 0; // Transparente
      }
    }

    tempCtx.putImageData(imageData, 0, 0);

    tempCanvas.toBlob(async (blob) => {
      try {
        const file = new File([blob], 'assinatura.png', { type: 'image/png' });
        const { file_url } = await base44.integrations.Core.UploadFile({ file });
        onChange(file_url);
      } catch (error) {
        console.error('Erro ao fazer upload da assinatura:', error);
      } finally {
        setIsUploading(false);
      }
    }, 'image/png', 0.95);
  };

  const limpar = () => {
    if (isUploading) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.strokeStyle = '#ccc';
    ctx.lineWidth = 1;
    ctx.setLineDash([5, 5]);
    ctx.strokeRect(10, 10, canvas.width - 20, canvas.height - 20);
    ctx.setLineDash([]);
    onChange('');
  };

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <Label className="text-gray-700 font-semibold">{titulo}</Label>
        {!assinatura && (
          <Button
            variant="ghost"
            size="sm"
            onClick={limpar}
            disabled={isUploading}
            className="text-red-600 hover:text-red-700 disabled:opacity-50"
          >
            <X className="w-4 h-4 mr-1" />
            Desfazer
          </Button>
        )}
        {assinatura && (
          <Button
            variant="ghost"
            size="sm"
            onClick={limpar}
            disabled={isUploading}
            className="text-red-600 hover:text-red-700 disabled:opacity-50"
          >
            <X className="w-4 h-4 mr-1" />
            Limpar
          </Button>
        )}
      </div>
      <div className="relative">
        <canvas
          ref={canvasRef}
          width={800}
          height={250}
          onMouseDown={startDrawing}
          onMouseMove={draw}
          onMouseUp={stopDrawing}
          onMouseLeave={stopDrawing}
          onTouchStart={startDrawing}
          onTouchMove={draw}
          onTouchEnd={stopDrawing}
          className="w-full border-2 border-gray-300 rounded-lg shadow-md cursor-crosshair bg-white transition-all"
          style={{ 
            touchAction: 'none',
            maxHeight: '200px',
            height: 'auto'
          }}
        />
        {isUploading && (
          <div className="absolute inset-0 bg-black/10 rounded-lg flex items-center justify-center">
            <span className="text-sm text-gray-700 font-medium">Salvando assinatura...</span>
          </div>
        )}
      </div>
      <div className="flex gap-2">
        <Button
          onClick={assinatura ? limpar : confirmarAssinatura}
          disabled={isUploading}
          className={`flex-1 text-white ${assinatura ? 'bg-green-600 hover:bg-green-700' : 'bg-blue-600 hover:bg-blue-700'}`}
        >
          {assinatura ? 'Assinatura Salva' : 'Confirmar Assinatura'}
        </Button>
      </div>
    </div>
  );
}

export default function AssinaturasTab({ ocorrencia, onChange }) {
  const handleEnvolvidoAssinaturaChange = (index, campos) => {
    const novosEnvolvidos = [...(ocorrencia.envolvidos || [])];
    novosEnvolvidos[index] = {
      ...novosEnvolvidos[index],
      ...campos
    };
    onChange({ ...ocorrencia, envolvidos: novosEnvolvidos });
  };

  return (
    <div className="space-y-6 p-4 pb-24">
      {ocorrencia.envolvidos && ocorrencia.envolvidos.length === 0 && (
        <div className="text-center py-12 text-gray-500">
          <p className="text-lg mb-2">Nenhum envolvido cadastrado</p>
          <p className="text-sm">Adicione envolvidos na aba "Envolvidos" para capturar suas assinaturas</p>
        </div>
      )}
      
      {/* Assinaturas dos Envolvidos */}
      {ocorrencia.envolvidos && ocorrencia.envolvidos.length > 0 && (
        ocorrencia.envolvidos.map((envolvido, index) => (
          <Card key={index} className="bg-blue-50/50">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg text-blue-900">
                {envolvido.nome_completo || `Envolvido ${index + 1}`}
                <span className="text-sm font-normal text-gray-600 ml-2">
                  ({envolvido.condicao || 'Não especificado'})
                </span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Autores: assinatura única para ambos os termos */}
              {envolvido.condicao === 'Autor' ? (
                <AssinaturaCanvas
                  titulo="Assinatura para Termo de Compromisso e Declaração"
                  assinatura={envolvido.assinatura_compromisso}
                  onChange={(sig) => {
                    handleEnvolvidoAssinaturaChange(index, {
                      assinatura_compromisso: sig,
                      assinatura_declaracao: sig
                    });
                  }}
                />
              ) : (
                /* Demais envolvidos: apenas assinatura de declaração */
                <AssinaturaCanvas
                  titulo="Assinatura para Termo de Declaração"
                  assinatura={envolvido.assinatura_declaracao}
                  onChange={(sig) => handleEnvolvidoAssinaturaChange(index, { assinatura_declaracao: sig })}
                />
              )}
            </CardContent>
          </Card>
        ))
      )}
    </div>
  );
}