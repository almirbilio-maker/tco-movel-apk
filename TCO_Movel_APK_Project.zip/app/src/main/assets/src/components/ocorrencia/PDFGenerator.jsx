import jsPDF from 'jspdf';

// Função para formatar data no estilo extenso
const formatarDataLocalExtenso = (data, local) => {
  if (!data || !local) return '';
  const dataObj = new Date(data);
  const dia = dataObj.getDate();
  const meses = ['janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho', 
                 'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro'];
  const mes = meses[dataObj.getMonth()];
  const ano = dataObj.getFullYear();
  return `${local}, ${dia} de ${mes} de ${ano}.`;
};

// Modelo 1: TERMO DE DECLARAÇÃO DE ENVOLVIDO (Autor)
export const generateDeclaracaoPDF = async (ocorrencia) => {
  const doc = new jsPDF();
  const pageWidth = doc.internal.pageSize.width;
  const margin = 20;
  const maxWidth = pageWidth - (margin * 2);
  let y = 15;

  // Cabeçalho
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text('Ministério da Justiça', 15, y);
  doc.text('PRF', pageWidth - 25, y);
  y += 4;
  doc.text('e Segurança Pública', 15, y);
  
  y += 10;
  doc.setFontSize(20);
  doc.setFont('helvetica', 'bold');
  doc.text('TCO', pageWidth / 2, y, { align: 'center' });
  
  y += 6;
  doc.setFontSize(11);
  doc.text('Termo Circunstanciado de Ocorrência', pageWidth / 2, y, { align: 'center' });
  
  y += 6;
  doc.setFontSize(10);
  doc.text(`Nº ${ocorrencia.numero || '___________'}`, pageWidth / 2, y, { align: 'center' });

  // Título em caixa
  y += 12;
  doc.setFillColor(255, 255, 255);
  doc.rect(margin, y - 5, maxWidth, 10, 'S');
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.text('Termo de Declaração de Envolvido', pageWidth / 2, y, { align: 'center' });

  // Checkboxes
  y += 15;
  doc.setFontSize(11);
  const checkSize = 5;
  doc.rect(margin, y - 4, checkSize, checkSize);
  doc.text('X', margin + 1.5, y);
  doc.setFont('helvetica', 'bold');
  doc.text('Autor', margin + 8, y);
  
  doc.rect(margin + 50, y - 4, checkSize, checkSize);
  doc.text('Vítima', margin + 58, y);
  
  doc.rect(margin + 100, y - 4, checkSize, checkSize);
  doc.text('Testemunha', margin + 108, y);

  // Corpo da declaração
  y += 15;
  doc.setFont('helvetica', 'normal');
  doc.text(`Eu, ${ocorrencia.nome_autor || '_____________________________________________'},`, margin, y);
  
  y += 7;
  doc.text(`CPF ${ocorrencia.cpf_autor || '______________________'}, voluntariamente, declaro QUE Termo de Declaração de Envolvido`, margin, y);

  // Espaço para declaração
  y += 10;
  const declaracaoLines = doc.splitTextToSize(ocorrencia.declaracao_autor || '', maxWidth);
  declaracaoLines.forEach(line => {
    if (y > 250) {
      doc.addPage();
      y = 20;
    }
    doc.text(line, margin, y);
    y += 6;
  });

  // Local e Data
  y = 230;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);
  const dataLocalTexto = formatarDataLocalExtenso(ocorrencia.data_lavratura, ocorrencia.local);
  doc.text(dataLocalTexto, pageWidth - margin, y, { align: 'right' });

  // Assinatura
  y = 260;
  if (ocorrencia.assinatura_autor_url) {
    doc.addImage(ocorrencia.assinatura_autor_url, 'PNG', pageWidth / 2 - 30, y - 25, 60, 20);
  }
  
  doc.line(margin, y, pageWidth - margin, y);
  y += 5;
  doc.setFont('helvetica', 'normal');
  doc.text('Declarante', pageWidth / 2, y, { align: 'center' });

  doc.save(`TCO_Declaracao_Autor_${ocorrencia.numero || 'SN'}.pdf`);
};

// Modelo 2: TERMO DE COMPROMISSO DE COMPARECIMENTO DO AUTOR
export const generateCompromissoPDF = async (ocorrencia) => {
  const doc = new jsPDF();
  const pageWidth = doc.internal.pageSize.width;
  const margin = 20;
  const maxWidth = pageWidth - (margin * 2);
  let y = 15;

  // Cabeçalho
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text('Ministério da Justiça', 15, y);
  doc.text('PRF', pageWidth - 25, y);
  y += 4;
  doc.text('e Segurança Pública', 15, y);
  
  y += 10;
  doc.setFontSize(20);
  doc.setFont('helvetica', 'bold');
  doc.text('TCO', pageWidth / 2, y, { align: 'center' });
  
  y += 6;
  doc.setFontSize(11);
  doc.text('Termo Circunstanciado de Ocorrência', pageWidth / 2, y, { align: 'center' });
  
  y += 6;
  doc.setFontSize(10);
  doc.text(`Nº ${ocorrencia.numero || '___________'}`, pageWidth / 2, y, { align: 'center' });

  // Título em caixa
  y += 12;
  doc.setFillColor(255, 255, 255);
  doc.rect(margin, y - 5, maxWidth, 10, 'S');
  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.text('TERMO DE COMPROMISSO DE COMPARECIMENTO DO AUTOR', pageWidth / 2, y, { align: 'center' });

  // Corpo do texto
  y += 12;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);
  
  let texto = `O Policial Rodoviário Federal ${ocorrencia.nome_prf || '_______________________'}, matrícula nº ${ocorrencia.matricula || '__________'}, com fulcro na Lei 9.099/95, faz saber a ${ocorrencia.nome_autor || '_______________________________________________'}, portador(a) do CPF nº ${ocorrencia.cpf_autor || '____________________________'} que, nesta data, foi lavrado o presente Termo Circunstanciado de Ocorrência (TCO), em seu desfavor.`;
  
  let linhas = doc.splitTextToSize(texto, maxWidth);
  linhas.forEach(linha => {
    doc.text(linha, margin, y);
    y += 5;
  });

  y += 3;
  texto = `Por meio do presente instrumento o arrolado assume o COMPROMISSO DE COMPARECER ao Juizado Especial Criminal da Comarca de ${ocorrencia.comarca || '_______________________'}, em dia e hora a serem determinados posteriormente quando da intimação feita pelo referido juízo na forma da lei, na qualidade de autor(a) dos fatos`;
  
  linhas = doc.splitTextToSize(texto, maxWidth);
  linhas.forEach(linha => {
    doc.text(linha, margin, y);
    y += 5;
  });

  y += 3;
  texto = `Fica ciente que o não comparecimento o sujeitará às medidas previstas na Lei nº 9.099/95, sem prejuízo das demais cominações legais pertinentes.`;
  
  linhas = doc.splitTextToSize(texto, maxWidth);
  linhas.forEach(linha => {
    doc.text(linha, margin, y);
    y += 5;
  });

  y += 3;
  texto = `É obrigatório que o autor dos fatos se faça acompanhar de advogado por ocasião do comparecimento àquele Juizado.`;
  
  linhas = doc.splitTextToSize(texto, maxWidth);
  linhas.forEach(linha => {
    doc.text(linha, margin, y);
    y += 5;
  });

  y += 3;
  texto = `Fica advertido que, na falta de um advogado, ser-lhe-á designado um defensor público, conforme disposto no art. 68 da supracitada lei.`;
  
  linhas = doc.splitTextToSize(texto, maxWidth);
  linhas.forEach(linha => {
    doc.text(linha, margin, y);
    y += 5;
  });

  // Informações do compromissado
  y += 5;
  doc.setFont('helvetica', 'bold');
  doc.text('O compromissado informa que:', margin, y);
  
  y += 7;
  doc.setFont('helvetica', 'normal');
  const checkSize = 4;
  doc.rect(margin, y - 3, checkSize, checkSize);
  if (ocorrencia.aceita_comunicacao) {
    doc.text('X', margin + 1, y);
  }
  
  texto = `Aceita receber comunicações referentes ao processo criminal por meio de mensagem eletrônica (SMS) e/ou via aplicativo de troca de mensagens, por meio do telefone celular de número: ${ocorrencia.telefone_autor || '__________________________'}.`;
  linhas = doc.splitTextToSize(texto, maxWidth - 8);
  linhas.forEach((linha, idx) => {
    doc.text(linha, margin + (idx === 0 ? 7 : 0), y);
    y += 5;
  });

  y += 2;
  doc.rect(margin, y - 3, checkSize, checkSize);
  if (ocorrencia.deseja_defensoria) {
    doc.text('X', margin + 1, y);
  }
  doc.text('Deseja receber assistência da Defensoria Pública.', margin + 7, y);

  // Local e Data
  y += 10;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);
  const dataLocalTexto = formatarDataLocalExtenso(ocorrencia.data_lavratura, ocorrencia.local);
  doc.text(dataLocalTexto, pageWidth / 2, y, { align: 'center' });

  // Assinaturas
  y += 15;
  if (ocorrencia.assinatura_autor_url) {
    doc.addImage(ocorrencia.assinatura_autor_url, 'PNG', pageWidth / 2 - 30, y, 60, 20);
  }
  y += 20;
  doc.line(pageWidth / 2 - 30, y, pageWidth / 2 + 30, y);
  y += 5;
  doc.text('Compromissado(a)', pageWidth / 2, y, { align: 'center' });

  y += 15;
  if (ocorrencia.assinatura_prf_url) {
    doc.addImage(ocorrencia.assinatura_prf_url, 'PNG', pageWidth / 2 - 30, y, 60, 20);
  }
  y += 20;
  doc.line(pageWidth / 2 - 30, y, pageWidth / 2 + 30, y);
  y += 5;
  doc.text('Policial Rodoviário Federal', pageWidth / 2, y, { align: 'center' });

  doc.save(`TCO_Compromisso_${ocorrencia.numero || 'SN'}.pdf`);
};

// TERMO DE DECLARAÇÃO DE TESTEMUNHA (mesmo modelo do autor)
export const generateDeclaracaoTestemunhaPDF = async (ocorrencia) => {
  if (!ocorrencia.tem_testemunha) return;

  const doc = new jsPDF();
  const pageWidth = doc.internal.pageSize.width;
  const margin = 20;
  const maxWidth = pageWidth - (margin * 2);
  let y = 15;

  // Cabeçalho
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text('Ministério da Justiça', 15, y);
  doc.text('PRF', pageWidth - 25, y);
  y += 4;
  doc.text('e Segurança Pública', 15, y);
  
  y += 10;
  doc.setFontSize(20);
  doc.setFont('helvetica', 'bold');
  doc.text('TCO', pageWidth / 2, y, { align: 'center' });
  
  y += 6;
  doc.setFontSize(11);
  doc.text('Termo Circunstanciado de Ocorrência', pageWidth / 2, y, { align: 'center' });
  
  y += 6;
  doc.setFontSize(10);
  doc.text(`Nº ${ocorrencia.numero || '___________'}`, pageWidth / 2, y, { align: 'center' });

  // Título em caixa
  y += 12;
  doc.setFillColor(255, 255, 255);
  doc.rect(margin, y - 5, maxWidth, 10, 'S');
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.text('Termo de Declaração de Envolvido', pageWidth / 2, y, { align: 'center' });

  // Checkboxes
  y += 15;
  doc.setFontSize(11);
  const checkSize = 5;
  doc.rect(margin, y - 4, checkSize, checkSize);
  doc.text('Autor', margin + 8, y);
  
  doc.rect(margin + 50, y - 4, checkSize, checkSize);
  doc.text('Vítima', margin + 58, y);
  
  doc.rect(margin + 100, y - 4, checkSize, checkSize);
  doc.text('X', margin + 101.5, y);
  doc.setFont('helvetica', 'bold');
  doc.text('Testemunha', margin + 108, y);

  // Corpo da declaração
  y += 15;
  doc.setFont('helvetica', 'normal');
  doc.text(`Eu, ${ocorrencia.nome_testemunha || '_____________________________________________'},`, margin, y);
  
  y += 7;
  doc.text(`CPF ${ocorrencia.cpf_testemunha || '______________________'}, voluntariamente, declaro QUE Termo de Declaração de Envolvido`, margin, y);

  // Espaço para declaração
  y += 10;
  const declaracaoLines = doc.splitTextToSize(ocorrencia.declaracao_testemunha || '', maxWidth);
  declaracaoLines.forEach(line => {
    if (y > 250) {
      doc.addPage();
      y = 20;
    }
    doc.text(line, margin, y);
    y += 6;
  });

  // Local e Data
  y = 230;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);
  const dataLocalTextoTest = formatarDataLocalExtenso(ocorrencia.data_lavratura, ocorrencia.local);
  doc.text(dataLocalTextoTest, pageWidth - margin, y, { align: 'right' });

  // Assinatura
  y = 260;
  if (ocorrencia.assinatura_testemunha_url) {
    doc.addImage(ocorrencia.assinatura_testemunha_url, 'PNG', pageWidth / 2 - 30, y - 25, 60, 20);
  }
  
  doc.line(margin, y, pageWidth - margin, y);
  y += 5;
  doc.setFont('helvetica', 'normal');
  doc.text('Declarante', pageWidth / 2, y, { align: 'center' });

  doc.save(`TCO_Declaracao_Testemunha_${ocorrencia.numero || 'SN'}.pdf`);
};

export const generateTCOPDF = async (ocorrencia) => {
  await generateDeclaracaoPDF(ocorrencia);
  await generateCompromissoPDF(ocorrencia);
  
  if (ocorrencia.tem_testemunha && ocorrencia.assinatura_testemunha_url) {
    await generateDeclaracaoTestemunhaPDF(ocorrencia);
  }
};