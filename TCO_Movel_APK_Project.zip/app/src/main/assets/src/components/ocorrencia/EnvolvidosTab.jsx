import React from 'react';
import { Input } from '@/components/ui/input';
import { InputValidado } from '@/components/ui/input-validado';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Plus, Trash2 } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import {
  formatarNome,
  formatarCPF,
  validarCPF,
  formatarTelefone,
  validarTelefone,
  formatarData,
  validarDataNaoFutura,
  formatarEndereco,
  limparTexto
} from '@/components/utils/validacoes';

export default function EnvolvidosTab({ envolvidos = [], onChange }) {
  const adicionarEnvolvido = () => {
    onChange([...envolvidos, {
      condicao: 'Autor',
      nome_completo: '',
      cpf: '',
      telefone_celular: '',
      endereco_logradouro: '',
      endereco_numero: '',
      endereco_bairro: '',
      endereco_referencia: '',
      endereco_municipio: '',
      naturalidade: '',
      nacionalidade: 'Brasileira',
      sexo: '',
      data_nascimento: '',
      estado_civil: '',
      profissao: '',
      escolaridade: '',
      etnia: '',
      identidade_genero: '',
      orientacao_sexual: '',
      declaracao: 'Após tomar plena ciência do inteiro teor da imputação, bem como de meus direitos constitucionais — em especial o de permanecer em silêncio e de não produzir prova contra mim mesmo, conforme assegurado pelo art. 5º, inciso LXIII, da Constituição Federal — opto por exercer referida prerrogativa neste ato. Por fim, manifesto que nada tenho a acrescentar ao presente termo, reservando-me o direito de prestar esclarecimentos em sede judicial.',
      aceita_comunicacao_eletronica: true,
      deseja_assistencia_defensoria: true
    }]);
  };

  const removerEnvolvido = (index) => {
    onChange(envolvidos.filter((_, i) => i !== index));
  };

  const atualizarEnvolvido = (index, campo, valor) => {
    const novosEnvolvidos = [...envolvidos];
    novosEnvolvidos[index][campo] = valor;
    onChange(novosEnvolvidos);
  };

  return (
    <div className="space-y-4 p-4 pb-24">
      {envolvidos.map((envolvido, index) => (
        <Card key={index} className="bg-white border-l-4 border-l-blue-900">
          <CardContent className="p-4 space-y-4">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-bold text-blue-900 text-lg">Envolvido {index + 1}</h3>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => removerEnvolvido(index)}
                className="text-red-600 hover:text-red-700 hover:bg-red-50"
              >
                <Trash2 className="w-4 h-4" />
              </Button>
            </div>

            {/* Condição */}
            <div>
              <Label className="text-gray-700 font-semibold">Condição *</Label>
              <Select
                value={envolvido.condicao}
                onValueChange={(value) => {
                  const novosEnvolvidos = [...envolvidos];
                  novosEnvolvidos[index].condicao = value;
                  const isAutorOuParticipe = value === 'Autor' || value === 'Partícipe';
                  if (!isAutorOuParticipe) {
                    novosEnvolvidos[index].declaracao = '';
                  } else if (!novosEnvolvidos[index].declaracao) {
                    novosEnvolvidos[index].declaracao = 'Após tomar plena ciência do inteiro teor da imputação, bem como de meus direitos constitucionais — em especial o de permanecer em silêncio e de não produzir prova contra mim mesmo, conforme assegurado pelo art. 5º, inciso LXIII, da Constituição Federal — opto por exercer referida prerrogativa neste ato. Por fim, manifesto que nada tenho a acrescentar ao presente termo, reservando-me o direito de prestar esclarecimentos em sede judicial.';
                  }
                  onChange(novosEnvolvidos);
                }}
              >
                <SelectTrigger className="mt-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                   <SelectItem value="Autor">Autor</SelectItem>
                   <SelectItem value="Testemunha">Testemunha</SelectItem>
                   <SelectItem value="Vítima">Vítima</SelectItem>
                   <SelectItem value="Partícipe">Partícipe</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* DADOS PESSOAIS OBRIGATÓRIOS */}
            <div className="border-t pt-3">
              <h4 className="font-semibold text-blue-900 mb-3">📌 Dados Pessoais (Obrigatórios)</h4>
              
              <div className="space-y-3">
                <InputValidado
                   label="Nome Completo"
                   value={envolvido.nome_completo || ''}
                   onChange={(valor) => atualizarEnvolvido(index, 'nome_completo', valor)}
                   formatacao={(valor) => valor.replace(/[^a-zA-ZÀ-ÿ\s]/g, '')}
                   onBlur={() => {
                     const nome = formatarNome(envolvido.nome_completo || '');
                     const resultado = envolvido.condicao === 'Autor' ? nome.toUpperCase() : nome;
                     atualizarEnvolvido(index, 'nome_completo', resultado);
                   }}
                   obrigatorio={true}
                   placeholder="Nome completo"
                   autoComplete="name"
                   autoCapitalize="words"
                   autoCorrect="off"
                 />

                <InputValidado
                  label="CPF"
                  value={envolvido.cpf || ''}
                  onChange={(valor) => atualizarEnvolvido(index, 'cpf', valor)}
                  formatacao={formatarCPF}
                  validacao={validarCPF}
                  mensagemErro="CPF inválido"
                  obrigatorio={true}
                  placeholder="000.000.000-00"
                  maxLength={14}
                  inputMode="numeric"
                />

                <InputValidado
                  label="Telefone Celular"
                  value={envolvido.telefone_celular || ''}
                  onChange={(valor) => atualizarEnvolvido(index, 'telefone_celular', valor)}
                  formatacao={formatarTelefone}
                  validacao={validarTelefone}
                  mensagemErro="Telefone inválido (11 dígitos)"
                  obrigatorio={true}
                  placeholder="(00)00000-0000"
                  maxLength={14}
                  inputMode="numeric"
                />
              </div>
            </div>

            {/* ENDEREÇO RESIDENCIAL */}
            <div className="border-t pt-3">
              <h4 className="font-semibold text-blue-900 mb-3">📍 Endereço Residencial (Obrigatório)</h4>
              
              <div className="space-y-3">
                <div>
                   <InputValidado
                     label="Logradouro"
                     value={envolvido.endereco_logradouro || ''}
                     onChange={(valor) => atualizarEnvolvido(index, 'endereco_logradouro', valor)}
                     onBlur={() => atualizarEnvolvido(index, 'endereco_logradouro', formatarEndereco(envolvido.endereco_logradouro || ''))}
                     validacao={(valor) => valor && valor.trim().length > 2}
                     mensagemErro="Logradouro deve ter no mínimo 3 caracteres"
                     obrigatorio={true}
                     placeholder="Rua, Avenida, etc."
                     autoComplete="address-line1"
                     autoCapitalize="words"
                     autoCorrect="on"
                   />
                 </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label className="text-gray-700 font-semibold">
                      Número <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      value={envolvido.endereco_numero || ''}
                      onChange={(e) => atualizarEnvolvido(index, 'endereco_numero', e.target.value)}
                      onBlur={(e) => atualizarEnvolvido(index, 'endereco_numero', e.target.value.replace(/\D/g, ''))}
                      placeholder="Nº"
                      className="mt-1"
                      inputMode="numeric"
                    />
                  </div>

                  <div>
                    <InputValidado
                      label="Bairro"
                      value={envolvido.endereco_bairro || ''}
                      onChange={(valor) => atualizarEnvolvido(index, 'endereco_bairro', valor)}
                      onBlur={() => atualizarEnvolvido(index, 'endereco_bairro', formatarEndereco(envolvido.endereco_bairro || ''))}
                      validacao={(valor) => valor && valor.trim().length > 1}
                      mensagemErro="Bairro deve ter no mínimo 2 caracteres"
                      obrigatorio={true}
                      placeholder="Bairro"
                      autoComplete="address-level3"
                      autoCapitalize="words"
                      autoCorrect="on"
                    />
                  </div>
                </div>

                <div>
                   <InputValidado
                     label="Ponto de Referência"
                     value={envolvido.endereco_referencia || ''}
                     onChange={(valor) => atualizarEnvolvido(index, 'endereco_referencia', valor)}
                     onBlur={() => atualizarEnvolvido(index, 'endereco_referencia', formatarEndereco(envolvido.endereco_referencia || ''))}
                     validacao={(valor) => valor && valor.trim().length > 2}
                     mensagemErro="Ponto de referência deve ter no mínimo 3 caracteres"
                     obrigatorio={true}
                     placeholder="Próximo a..."
                     autoCapitalize="words"
                     autoCorrect="on"
                   />
                 </div>

                <div>
                   <InputValidado
                     label="Município"
                     value={envolvido.endereco_municipio || ''}
                     onChange={(valor) => atualizarEnvolvido(index, 'endereco_municipio', valor)}
                     onBlur={() => {
                       const texto = envolvido.endereco_municipio || '';
                       const partes = texto.split('-').map(p => p.trim());
                       let resultado = texto;
                       if (partes.length === 2) {
                         resultado = `${formatarNome(partes[0])}-${partes[1].toUpperCase()}`;
                       } else {
                         resultado = formatarNome(texto);
                       }
                       atualizarEnvolvido(index, 'endereco_municipio', resultado);
                     }}
                     validacao={(valor) => valor && valor.trim().length > 2}
                     mensagemErro="Município deve ter no mínimo 3 caracteres"
                     obrigatorio={true}
                     placeholder="Cidade/UF"
                     autoComplete="address-level2"
                     autoCapitalize="words"
                     autoCorrect="on"
                   />
                 </div>
              </div>
            </div>

            {/* DADOS FACULTATIVOS */}
            <div className="border-t pt-3">
              <h4 className="font-semibold text-gray-500 mb-3">📋 Dados Complementares (Facultativos)</h4>
              
              <div className="space-y-3">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label className="text-gray-600 text-sm">Naturalidade</Label>
                    <Input
                      value={envolvido.naturalidade || ''}
                      onChange={(e) => atualizarEnvolvido(index, 'naturalidade', e.target.value)}
                      onBlur={(e) => {
                        const texto = e.target.value;
                        const partes = texto.split('-').map(p => p.trim());
                        let resultado = texto;
                        if (partes.length === 2) {
                          resultado = `${formatarNome(partes[0])} - ${partes[1].toUpperCase()}`;
                        } else {
                          resultado = formatarNome(texto);
                        }
                        atualizarEnvolvido(index, 'naturalidade', resultado);
                      }}
                      placeholder="Cidade de nascimento"
                      className="mt-1"
                      autoComplete="off"
                      autoCapitalize="words"
                      autoCorrect="on"
                    />
                  </div>

                  <div>
                    <Label className="text-gray-600 text-sm">Nacionalidade</Label>
                    <Input
                      value={envolvido.nacionalidade || ''}
                      onChange={(e) => atualizarEnvolvido(index, 'nacionalidade', e.target.value)}
                      onBlur={(e) => atualizarEnvolvido(index, 'nacionalidade', formatarNome(e.target.value))}
                      placeholder="Ex: Brasileira"
                      className="mt-1"
                      autoComplete="country-name"
                      autoCapitalize="words"
                      autoCorrect="on"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label className="text-gray-600 text-sm">Sexo</Label>
                    <Select
                      value={envolvido.sexo || ''}
                      onValueChange={(value) => atualizarEnvolvido(index, 'sexo', value)}
                    >
                      <SelectTrigger className="mt-1">
                        <SelectValue placeholder="Selecione" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Masculino">Masculino</SelectItem>
                        <SelectItem value="Feminino">Feminino</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <InputValidado
                    label="Data de Nascimento"
                    value={envolvido.data_nascimento || ''}
                    onChange={(valor) => atualizarEnvolvido(index, 'data_nascimento', valor)}
                    formatacao={formatarData}
                    validacao={validarDataNaoFutura}
                    mensagemErro="Data inválida ou futura"
                    placeholder="DD/MM/AAAA"
                    maxLength={10}
                    inputMode="numeric"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label className="text-gray-600 text-sm">Estado Civil</Label>
                    <Input
                      value={envolvido.estado_civil || ''}
                      onChange={(e) => atualizarEnvolvido(index, 'estado_civil', e.target.value)}
                      onBlur={(e) => atualizarEnvolvido(index, 'estado_civil', formatarNome(e.target.value))}
                      placeholder="Ex: Solteiro(a)"
                      className="mt-1"
                    />
                  </div>

                  <div>
                    <Label className="text-gray-600 text-sm">Profissão</Label>
                    <Input
                      value={envolvido.profissao || ''}
                      onChange={(e) => atualizarEnvolvido(index, 'profissao', e.target.value)}
                      onBlur={(e) => atualizarEnvolvido(index, 'profissao', formatarNome(e.target.value))}
                      placeholder="Profissão"
                      className="mt-1"
                      autoComplete="organization-title"
                      autoCapitalize="words"
                      autoCorrect="on"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label className="text-gray-600 text-sm">Escolaridade</Label>
                    <Input
                      value={envolvido.escolaridade || ''}
                      onChange={(e) => atualizarEnvolvido(index, 'escolaridade', e.target.value)}
                      onBlur={(e) => atualizarEnvolvido(index, 'escolaridade', formatarNome(e.target.value))}
                      placeholder="Ex: Ensino Médio"
                      className="mt-1"
                    />
                  </div>

                  <div>
                    <Label className="text-gray-600 text-sm">Etnia</Label>
                    <Input
                      value={envolvido.etnia || ''}
                      onChange={(e) => atualizarEnvolvido(index, 'etnia', e.target.value)}
                      onBlur={(e) => atualizarEnvolvido(index, 'etnia', formatarNome(e.target.value))}
                      placeholder="Etnia"
                      className="mt-1"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label className="text-gray-600 text-sm">Identidade de Gênero</Label>
                    <Input
                      value={envolvido.identidade_genero || ''}
                      onChange={(e) => atualizarEnvolvido(index, 'identidade_genero', e.target.value)}
                      onBlur={(e) => atualizarEnvolvido(index, 'identidade_genero', formatarNome(e.target.value))}
                      placeholder="Identidade de gênero"
                      className="mt-1"
                    />
                  </div>

                  <div>
                    <Label className="text-gray-600 text-sm">Orientação Sexual</Label>
                    <Input
                      value={envolvido.orientacao_sexual || ''}
                      onChange={(e) => atualizarEnvolvido(index, 'orientacao_sexual', e.target.value)}
                      onBlur={(e) => atualizarEnvolvido(index, 'orientacao_sexual', formatarNome(e.target.value))}
                      placeholder="Orientação sexual"
                      className="mt-1"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* DECLARAÇÃO DO ENVOLVIDO */}
            <div className="border-t pt-3">
              <h4 className="font-semibold text-blue-900 mb-3">📝 Declaração</h4>
              <div>
                <Label htmlFor={`declaracao-${index}`}>Texto da Declaração</Label>
                <Textarea
                  id={`declaracao-${index}`}
                  placeholder="Digite aqui a declaração completa do envolvido..."
                  value={envolvido.declaracao || ''}
                  onChange={(e) => atualizarEnvolvido(index, 'declaracao', e.target.value)}
                  className="min-h-[120px] mt-1"
                  autoComplete="off"
                  autoCapitalize="sentences"
                  autoCorrect="on"
                  spellCheck="true"
                />
              </div>
            </div>

            {/* OPÇÕES DE COMUNICAÇÃO E ASSISTÊNCIA */}
            {(envolvido.condicao === 'Autor' || envolvido.condicao === 'Partícipe') && (
              <div className="border-t pt-3">
                <h4 className="font-semibold text-blue-900 mb-3">⚖️ Opções Processuais</h4>
                
                <div className="space-y-3">
                  <div className="flex items-start gap-3 p-3 bg-blue-50 rounded-lg">
                    <Checkbox
                      id={`comunicacao-${index}`}
                      checked={envolvido.aceita_comunicacao_eletronica || false}
                      onCheckedChange={(checked) => atualizarEnvolvido(index, 'aceita_comunicacao_eletronica', checked)}
                      className="mt-1"
                    />
                    <div className="flex-1">
                      <Label htmlFor={`comunicacao-${index}`} className="text-sm font-medium text-gray-700 cursor-pointer">
                        Aceita receber comunicações referentes ao processo criminal por meio de mensagem eletrônica (SMS) e/ou via aplicativo de troca de mensagens
                      </Label>
                      <p className="text-xs text-gray-600 mt-1">
                        Telefone celular: {envolvido.telefone_celular || 'não informado'}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3 p-3 bg-blue-50 rounded-lg">
                    <Checkbox
                      id={`defensoria-${index}`}
                      checked={envolvido.deseja_assistencia_defensoria || false}
                      onCheckedChange={(checked) => atualizarEnvolvido(index, 'deseja_assistencia_defensoria', checked)}
                      className="mt-1"
                    />
                    <div className="flex-1">
                      <Label htmlFor={`defensoria-${index}`} className="text-sm font-medium text-gray-700 cursor-pointer">
                        Deseja receber assistência da Defensoria Pública
                      </Label>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      ))}

      <Button
        onClick={adicionarEnvolvido}
        className="w-full bg-blue-900 hover:bg-blue-800 text-yellow-400 py-6 text-base font-semibold"
      >
        <Plus className="w-5 h-5 mr-2" />
        Adicionar Envolvido
      </Button>

      {envolvidos.length > 0 && (
        <div className="text-xs text-gray-500 text-center">
          * Campos obrigatórios devem ser preenchidos
        </div>
      )}
    </div>
  );
}