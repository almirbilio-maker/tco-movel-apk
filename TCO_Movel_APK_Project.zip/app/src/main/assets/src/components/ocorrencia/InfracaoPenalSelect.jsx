import React, { useState, useMemo } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { X, Search } from 'lucide-react';

export default function InfracaoPenalSelect({ valores = [], onChange }) {
  const [busca, setBusca] = useState('');
  const [aberto, setAberto] = useState(false);

  const { data: infracoes = [] } = useQuery({
    queryKey: ['infracoes_penais'],
    queryFn: () => base44.entities.InfracaoPenal.list(),
    initialData: [],
  });

  const infracoesFiltradas = useMemo(() => {
    if (!busca.trim()) return infracoes;

    const buscaLower = busca.toLowerCase();
    return infracoes.filter(inf =>
      inf.artigo?.toLowerCase().includes(buscaLower) ||
      inf.descricao?.toLowerCase().includes(buscaLower) ||
      inf.diploma_legal?.toLowerCase().includes(buscaLower) ||
      inf.palavras_chave?.some(p => p.toLowerCase().includes(buscaLower))
    );
  }, [busca, infracoes]);

  const infracoesLidas = infracoes.filter(inf => valores.includes(inf.id));

  const handleToggle = (id) => {
    const novo = valores.includes(id)
      ? valores.filter(v => v !== id)
      : [...valores, id];
    onChange(novo);
  };

  const handleRemover = (id) => {
    onChange(valores.filter(v => v !== id));
  };

  return (
    <div className="space-y-3">
      <Label className="text-gray-700 font-semibold">
        Infração Penal (Menor Potencial Ofensivo) *
      </Label>

      {/* Campo de busca */}
      <div className="relative">
        <div className="flex items-center gap-2 border rounded-md p-2 bg-white">
          <Search className="w-4 h-4 text-gray-400" />
          <Input
            type="text"
            placeholder="Buscar por artigo, crime ou lei..."
            value={busca}
            onChange={(e) => setBusca(e.target.value)}
            onFocus={() => setAberto(true)}
            className="border-0 focus:ring-0 p-0 h-auto"
          />
        </div>

        {/* Dropdown */}
        {aberto && (
          <>
            <div
              className="fixed inset-0 z-40"
              onClick={() => setAberto(false)}
            />
            <div className="absolute top-full left-0 right-0 z-50 bg-white border border-gray-300 rounded-md shadow-lg max-h-64 overflow-y-auto mt-1">
              {infracoesFiltradas.length === 0 ? (
                <div className="p-3 text-gray-500 text-sm">Nenhuma infração encontrada</div>
              ) : (
                infracoesFiltradas.map((inf) => (
                  <div
                    key={inf.id}
                    className="p-3 border-b last:border-b-0 hover:bg-blue-50 cursor-pointer"
                    onClick={() => handleToggle(inf.id)}
                  >
                    <div className="flex items-start gap-2">
                      <Checkbox
                        checked={valores.includes(inf.id)}
                        onChange={() => handleToggle(inf.id)}
                        className="mt-1"
                      />
                      <div className="flex-1 min-w-0">
                        <div className="font-semibold text-sm">
                          {inf.diploma_legal} – Art. {inf.artigo}
                        </div>
                        <div className="text-sm text-gray-700">{inf.descricao}</div>
                        <div className="text-xs text-gray-500 mt-1">
                          Pena: {inf.pena_minima} a {inf.pena_maxima}
                        </div>
                        <div className="text-xs text-blue-600 font-semibold">
                          {inf.classificacao}
                        </div>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </>
        )}
      </div>

      {/* Seleções ativas */}
      {infracoesLidas.length > 0 && (
        <div className="space-y-2">
          {infracoesLidas.map((inf) => (
            <div
              key={inf.id}
              className="bg-blue-50 border border-blue-200 rounded-md p-3 flex justify-between items-start"
            >
              <div className="flex-1">
                <div className="font-semibold text-sm">
                  {inf.diploma_legal} – Art. {inf.artigo}
                </div>
                <div className="text-sm text-gray-700">{inf.descricao}</div>
              </div>
              <button
                onClick={() => handleRemover(inf.id)}
                className="ml-2 p-1 hover:bg-blue-200 rounded transition-colors"
              >
                <X className="w-4 h-4 text-gray-600" />
              </button>
            </div>
          ))}
        </div>
      )}

      {valores.length === 0 && (
        <div className="text-sm text-orange-600 bg-orange-50 border border-orange-200 rounded-md p-2">
          Campo obrigatório
        </div>
      )}
    </div>
  );
}