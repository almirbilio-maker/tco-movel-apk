import React, { useEffect } from 'react';
import { InputValidado } from '@/components/ui/input-validado';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { formatarNome, formatarLocal, limparTexto } from '@/components/utils/validacoes';
import InfracaoPenalSelect from './InfracaoPenalSelect';

export default function DadosGeraisTab({ dados, onChange, operador }) {
  useEffect(() => {
    if (operador && !dados.policial_responsavel) {
      onChange({
        policial_responsavel: operador.nome_completo,
        matricula_policial: operador.matricula
      });
    }
  }, [operador, dados]);

  return (
    <div className="space-y-4 p-4 pb-24">
      <div>
        <Label htmlFor="numero_tco" className="text-gray-700 font-semibold">
          Número do TCO <span className="text-red-500">*</span>
        </Label>
        <Input
          id="numero_tco"
          value={dados.numero_tco || ''}
          onChange={(e) => onChange({ numero_tco: limparTexto(e.target.value) })}
          placeholder="Ex: 001/2026"
          className="mt-1"
          autoComplete="off"
          inputMode="text"
        />
      </div>

      <div>
        <Label htmlFor="local" className="text-gray-700 font-semibold">
          Local <span className="text-red-500">*</span>
        </Label>
        <Input
          id="local"
          value={dados.local || ''}
          onChange={(e) => onChange({ local: limparTexto(e.target.value) })}
          onBlur={(e) => onChange({ local: formatarLocal(e.target.value) })}
          placeholder="Ex: BR-101, Km 200, Cidade-UF"
          className="mt-1"
          autoComplete="street-address"
          autoCapitalize="words"
          autoCorrect="on"
        />
      </div>

      <div>
        <Label htmlFor="data" className="text-gray-700 font-semibold">
          Data <span className="text-red-500">*</span>
        </Label>
        <Input
          id="data"
          type="date"
          value={dados.data || ''}
          onChange={(e) => onChange({ data: e.target.value })}
          max={new Date().toISOString().split('T')[0]}
          className="mt-1"
        />
      </div>

      <div>
         <Label htmlFor="comarca" className="text-gray-700 font-semibold">Comarca</Label>
         <Input
           id="comarca"
           value={dados.comarca || ''}
           onChange={(e) => onChange({ comarca: limparTexto(e.target.value) })}
           onBlur={(e) => {
             const texto = e.target.value;
             const partes = texto.split('-').map(p => p.trim());
             let resultado = texto;
             if (partes.length === 2) {
               resultado = `${formatarNome(partes[0])}-${partes[1].toUpperCase()}`;
             } else {
               resultado = formatarNome(texto);
             }
             onChange({ comarca: resultado });
           }}
           placeholder="Ex: São Paulo"
           className="mt-1"
           autoComplete="address-level2"
           autoCapitalize="words"
           autoCorrect="on"
         />
       </div>

       <InfracaoPenalSelect 
         valores={dados.infracoes_penais || []}
         onChange={(valores) => onChange({ infracoes_penais: valores })}
       />

       <div className="pt-4 border-t">
        <h3 className="text-sm font-semibold text-gray-700 mb-3">Policial Responsável</h3>
        
        <div className="space-y-3">
          <div>
            <Label htmlFor="policial_responsavel" className="text-gray-600 text-sm">Nome</Label>
            <Input
              id="policial_responsavel"
              value={dados.policial_responsavel || ''}
              onChange={(e) => onChange({ policial_responsavel: limparTexto(e.target.value) })}
              onBlur={(e) => onChange({ policial_responsavel: formatarNome(e.target.value) })}
              placeholder="Nome completo"
              className="mt-1"
              autoComplete="name"
              autoCapitalize="words"
              autoCorrect="off"
            />
          </div>

          <div>
            <Label htmlFor="matricula_policial" className="text-gray-600 text-sm">Matrícula</Label>
            <Input
              id="matricula_policial"
              value={dados.matricula_policial || ''}
              onChange={(e) => onChange({ matricula_policial: limparTexto(e.target.value) })}
              placeholder="Matrícula"
              className="mt-1"
              inputMode="numeric"
              autoComplete="off"
              autoCorrect="off"
            />
          </div>
        </div>
      </div>
    </div>
  );
}