// Utilitários de validação e formatação de dados

// Formatar nome próprio (primeira letra maiúscula)
export const formatarNome = (texto) => {
  if (!texto) return '';
  
  return texto
    .toLowerCase()
    .trim()
    .replace(/\s+/g, ' ')
    .split(' ')
    .map(palavra => {
      // Exceções que ficam em minúsculo
      const excecoes = ['de', 'da', 'do', 'dos', 'das', 'e'];
      if (excecoes.includes(palavra) && palavra.length <= 2) {
        return palavra;
      }
      return palavra.charAt(0).toUpperCase() + palavra.slice(1);
    })
    .join(' ');
};

// Formatar local conforme norma de redação oficial
export const formatarLocal = (texto) => {
  if (!texto) return '';
  
  let resultado = texto.trim().replace(/\s+/g, ' ');
  
  // Deixar rodovia em maiúsculas (BR-xxx, BA-xxx, etc)
  resultado = resultado.replace(/\b([a-z]{2,})-(\d+)\b/gi, (match, sigla, numero) => {
    return sigla.toUpperCase() + '-' + numero;
  });
  
  // Deixar estado em maiúsculas (apenas as últimas 2 letras após hífen)
  resultado = resultado.replace(/,\s*([a-z]{2})\s*$/i, (match, uf) => {
    return ', ' + uf.toUpperCase();
  });
  
  // Capitalizar cidades e ruas normalmente
  resultado = resultado
    .split(/(\s+|-|,)/)
    .map((palavra, index) => {
      // Manter separadores como são
      if (!palavra || /^[\s,-]+$/.test(palavra)) return palavra;
      
      // Palavras que ficam em minúsculo
      const minusculas = ['de', 'da', 'do', 'dos', 'das', 'a', 'o', 'e', 'ou', 'em', 'por'];
      if (minusculas.includes(palavra.toLowerCase()) && index > 0) {
        return palavra.toLowerCase();
      }
      
      // Não formatar rodovias e estados (já foram processados acima)
      if (/^[A-Z]{2}-\d+$/.test(palavra) || /^[A-Z]{2}$/.test(palavra)) {
        return palavra;
      }
      
      return palavra.charAt(0).toUpperCase() + palavra.slice(1).toLowerCase();
    })
    .join('');
    
  return resultado;
};

// Formatar marca/modelo de veículo
export const formatarMarcaModelo = (texto) => {
  if (!texto) return '';
  
  // Remove espaços extras e converte para maiúsculas
  const limpo = texto.trim().replace(/\s+/g, '').toUpperCase();
  
  // Procura por barra ou espaço original para separar marca e modelo
  const comBarra = texto.includes('/');
  const partes = comBarra 
    ? texto.split('/').map(p => p.trim().replace(/\s+/g, '').toUpperCase())
    : texto.trim().split(/\s+/).map(p => p.toUpperCase()).filter(p => p);
  
  // Se conseguiu separar em partes, junta com barra
  if (partes.length >= 2) {
    return partes.slice(0, 2).join('/');
  }
  
  // Se não conseguiu separar, retorna o texto limpo
  return limpo;
};

// Validar CPF
export const validarCPF = (cpf) => {
  cpf = cpf.replace(/\D/g, '');
  
  if (cpf.length !== 11) return false;
  if (/^(\d)\1{10}$/.test(cpf)) return false;

  let soma = 0;
  for (let i = 0; i < 9; i++) {
    soma += parseInt(cpf.charAt(i)) * (10 - i);
  }
  let resto = 11 - (soma % 11);
  let digito1 = resto >= 10 ? 0 : resto;

  if (digito1 !== parseInt(cpf.charAt(9))) return false;

  soma = 0;
  for (let i = 0; i < 10; i++) {
    soma += parseInt(cpf.charAt(i)) * (11 - i);
  }
  resto = 11 - (soma % 11);
  let digito2 = resto >= 10 ? 0 : resto;

  return digito2 === parseInt(cpf.charAt(10));
};

// Formatar CPF com máscara
export const formatarCPF = (valor) => {
  const numeros = valor.replace(/\D/g, '');
  
  if (numeros.length <= 3) return numeros;
  if (numeros.length <= 6) return `${numeros.slice(0, 3)}.${numeros.slice(3)}`;
  if (numeros.length <= 9) return `${numeros.slice(0, 3)}.${numeros.slice(3, 6)}.${numeros.slice(6)}`;
  return `${numeros.slice(0, 3)}.${numeros.slice(3, 6)}.${numeros.slice(6, 9)}-${numeros.slice(9, 11)}`;
};

// Formatar telefone celular
export const formatarTelefone = (valor) => {
  const numeros = valor.replace(/\D/g, '');
  
  if (numeros.length <= 2) return numeros;
  if (numeros.length <= 7) return `(${numeros.slice(0, 2)})${numeros.slice(2)}`;
  if (numeros.length <= 11) {
    return `(${numeros.slice(0, 2)})${numeros.slice(2, 7)}-${numeros.slice(7, 11)}`;
  }
  return `(${numeros.slice(0, 2)})${numeros.slice(2, 7)}-${numeros.slice(7, 11)}`;
};

// Validar telefone
export const validarTelefone = (telefone) => {
  const numeros = telefone.replace(/\D/g, '');
  return numeros.length === 11;
};

// Formatar data
export const formatarData = (valor) => {
  const numeros = valor.replace(/\D/g, '');
  
  if (numeros.length <= 2) return numeros;
  if (numeros.length <= 4) return `${numeros.slice(0, 2)}/${numeros.slice(2)}`;
  return `${numeros.slice(0, 2)}/${numeros.slice(2, 4)}/${numeros.slice(4, 8)}`;
};

// Validar data
export const validarData = (data) => {
  const match = data.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
  if (!match) return false;

  const dia = parseInt(match[1]);
  const mes = parseInt(match[2]);
  const ano = parseInt(match[3]);

  if (mes < 1 || mes > 12) return false;
  if (dia < 1 || dia > 31) return false;
  if (ano < 1900 || ano > 2100) return false;

  const diasPorMes = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Verifica ano bissexto
  if ((ano % 4 === 0 && ano % 100 !== 0) || ano % 400 === 0) {
    diasPorMes[1] = 29;
  }

  if (dia > diasPorMes[mes - 1]) return false;

  return true;
};

// Validar data não futura
export const validarDataNaoFutura = (data) => {
  if (!validarData(data)) return false;
  
  const match = data.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
  const dataInput = new Date(match[3], match[2] - 1, match[1]);
  const hoje = new Date();
  hoje.setHours(0, 0, 0, 0);
  
  return dataInput <= hoje;
};

// Formatar placa de veículo
export const formatarPlaca = (valor) => {
  return valor.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 7);
};

// Validar placa (Mercosul e antiga)
export const validarPlaca = (placa) => {
  placa = placa.toUpperCase().replace(/[^A-Z0-9]/g, '');
  
  // Padrão antigo: ABC1234
  const padraoAntigo = /^[A-Z]{3}\d{4}$/;
  // Padrão Mercosul: ABC1D23
  const padraoMercosul = /^[A-Z]{3}\d[A-Z]\d{2}$/;
  
  return padraoAntigo.test(placa) || padraoMercosul.test(placa);
};

// Formatar endereço
export const formatarEndereco = (texto) => {
  if (!texto) return '';
  
  return texto
    .trim()
    .replace(/\s+/g, ' ')
    .replace(/,+/g, ',')
    .split(' ')
    .map((palavra, index) => {
      const minusculas = ['de', 'da', 'do', 'dos', 'das'];
      if (index > 0 && minusculas.includes(palavra.toLowerCase())) {
        return palavra.toLowerCase();
      }
      return palavra.charAt(0).toUpperCase() + palavra.slice(1).toLowerCase();
    })
    .join(' ');
};

// Limpar texto (remover espaços duplos e trim)
export const limparTexto = (texto) => {
  if (!texto) return '';
  return texto.trim().replace(/\s+/g, ' ');
};

// Converter para ISO date (YYYY-MM-DD)
export const converterParaISO = (dataBR) => {
  if (!dataBR) return '';
  const match = dataBR.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
  if (!match) return '';
  return `${match[3]}-${match[2]}-${match[1]}`;
};

// Converter de ISO para BR (DD/MM/YYYY)
export const converterParaBR = (dataISO) => {
  if (!dataISO) return '';
  const match = dataISO.match(/^(\d{4})-(\d{2})-(\d{2})/);
  if (!match) return '';
  return `${match[3]}/${match[2]}/${match[1]}`;
};

// Extrair apenas Cidade-UF do local (últimaparte após última vírgula)
export const extrairCidadeUF = (local) => {
  if (!local) return '';
  const partes = local.split(',').map(p => p.trim());
  return partes[partes.length - 1] || local;
};

// Formatar cidade-UF (deixar estado em maiúsculas)
export const formatarCidadeUF = (texto) => {
  if (!texto) return '';
  
  const partes = texto.split('-').map(p => p.trim());
  
  if (partes.length === 2) {
    // Formata "Cidade - UF"
    const cidade = formatarNome(partes[0]);
    const uf = partes[1].toUpperCase();
    return `${cidade} - ${uf}`;
  }
  
  return formatarNome(texto);
};

// Formatar data por extenso (Cidade-UF, dia de mês de ano)
export const formatarDataExtensoComLocal = (data, local) => {
  if (!data || !local) return '';
  const meses = ['janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho', 
                 'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro'];
  const dataObj = new Date(data + 'T00:00:00');
  const dia = dataObj.getDate();
  const mes = meses[dataObj.getMonth()];
  const ano = dataObj.getFullYear();
  const cidadeUF = extrairCidadeUF(local);
  return `${cidadeUF}, ${dia} de ${mes} de ${ano}`;
};