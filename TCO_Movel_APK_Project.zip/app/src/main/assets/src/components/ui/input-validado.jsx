import React, { useState, useEffect } from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { CheckCircle2, AlertCircle } from 'lucide-react';

export function InputValidado({
  label,
  value,
  onChange,
  onBlur,
  validacao,
  formatacao,
  tipo = 'text',
  obrigatorio = false,
  mensagemErro = '',
  placeholder = '',
  maxLength,
  inputMode,
  className = '',
  autoComplete,
  autoCapitalize,
  autoCorrect,
  spellCheck
}) {
  const [erro, setErro] = useState('');
  const [valido, setValido] = useState(false);
  const [touched, setTouched] = useState(false);

  useEffect(() => {
    if (touched && value) {
      if (validacao) {
        const isValido = validacao(value);
        setValido(isValido);
        setErro(isValido ? '' : mensagemErro);
      } else {
        setValido(true);
        setErro('');
      }
    } else if (touched && obrigatorio && !value) {
      setErro('Campo obrigatório');
      setValido(false);
    } else {
      setErro('');
      setValido(false);
    }
  }, [value, touched]);

  const handleChange = (e) => {
    let novoValor = e.target.value;
    
    if (formatacao) {
      novoValor = formatacao(novoValor);
    }
    
    onChange(novoValor);
  };

  const handleBlur = (e) => {
    setTouched(true);
    if (onBlur) {
      onBlur(e);
    }
  };

  const getBorderColor = () => {
    if (!touched) return '';
    if (erro) return 'border-red-500 focus:border-red-500 focus:ring-2 focus:ring-red-200 bg-red-50';
    if (valido) return 'border-green-500 focus:border-green-500 focus:ring-2 focus:ring-green-200 bg-green-50';
    return '';
  };

  return (
    <div className="space-y-1">
      {label && (
        <Label className="text-gray-700 font-semibold">
          {label}
          {obrigatorio && <span className="text-red-500 ml-1">*</span>}
        </Label>
      )}
      <div className="relative">
        <Input
          type={tipo}
          value={value}
          onChange={handleChange}
          onBlur={handleBlur}
          placeholder={placeholder}
          maxLength={maxLength}
          inputMode={inputMode}
          autoComplete={autoComplete || 'off'}
          autoCapitalize={autoCapitalize || 'none'}
          autoCorrect={autoCorrect || 'off'}
          spellCheck={spellCheck || 'false'}
          className={`${getBorderColor()} ${className} pr-10`}
        />
        {touched && (
          <div className="absolute right-3 top-1/2 -translate-y-1/2">
            {valido && <CheckCircle2 className="w-5 h-5 text-green-500" />}
            {erro && <AlertCircle className="w-5 h-5 text-red-500" />}
          </div>
        )}
      </div>
      {erro && touched && (
        <p className="text-sm text-red-600 flex items-center gap-1">
          <AlertCircle className="w-4 h-4" />
          {erro}
        </p>
      )}
    </div>
  );
}