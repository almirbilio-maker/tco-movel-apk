import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '../utils';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { ArrowLeft, Save, User } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';

export default function DadosOperador() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  
  const [dados, setDados] = useState({
    nome_completo: '',
    matricula: '',
    cpf: '',
    posto_graduacao: '',
    unidade: ''
  });

  const { data: operador } = useQuery({
    queryKey: ['operador'],
    queryFn: async () => {
      const lista = await base44.entities.Operador.list();
      return lista[0] || null;
    },
  });

  useEffect(() => {
    if (operador) {
      setDados(operador);
    }
  }, [operador]);

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Operador.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['operador'] });
      navigate(createPageUrl('Home'));
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Operador.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['operador'] });
      navigate(createPageUrl('Home'));
    },
  });

  const handleSalvar = () => {
    if (operador) {
      updateMutation.mutate({ id: operador.id, data: dados });
    } else {
      createMutation.mutate(dados);
    }
  };

  const formatCPF = (value) => {
    const numbers = value.replace(/\D/g, '');
    if (numbers.length <= 11) {
      return numbers
        .replace(/(\d{3})(\d)/, '$1.$2')
        .replace(/(\d{3})(\d)/, '$1.$2')
        .replace(/(\d{3})(\d{1,2})$/, '$1-$2');
    }
    return value;
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-24">
      {/* Header */}
      <div className="bg-blue-950 px-4 py-3 flex items-center gap-3 border-b border-blue-800">
        <button
          onClick={() => navigate(createPageUrl('Home'))}
          className="p-2 hover:bg-blue-800 rounded-lg transition-colors"
        >
          <ArrowLeft className="w-5 h-5 text-yellow-400" />
        </button>
        <h1 className="text-lg font-bold text-yellow-400">Dados do Operador</h1>
      </div>

      <div className="p-4">
        <Card className="bg-white">
          <CardContent className="p-6 space-y-4">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center">
                <User className="w-6 h-6 text-blue-900" />
              </div>
              <div>
                <h2 className="font-semibold text-blue-900">Cadastro PRF</h2>
                <p className="text-sm text-gray-600">
                  Estes dados serão aplicados automaticamente nas ocorrências
                </p>
              </div>
            </div>

            <div>
              <Label htmlFor="nome_completo" className="text-gray-700 font-semibold">
                Nome Completo *
              </Label>
              <Input
                id="nome_completo"
                value={dados.nome_completo}
                onChange={(e) => setDados({ ...dados, nome_completo: e.target.value })}
                placeholder="Nome completo"
                className="mt-1"
              />
            </div>

            <div>
              <Label htmlFor="matricula" className="text-gray-700 font-semibold">
                Matrícula *
              </Label>
              <Input
                id="matricula"
                value={dados.matricula}
                onChange={(e) => setDados({ ...dados, matricula: e.target.value })}
                placeholder="Número de matrícula"
                className="mt-1"
              />
            </div>

            <div>
              <Label htmlFor="cpf" className="text-gray-700 font-semibold">
                CPF
              </Label>
              <Input
                id="cpf"
                value={dados.cpf}
                onChange={(e) => setDados({ ...dados, cpf: formatCPF(e.target.value) })}
                placeholder="000.000.000-00"
                maxLength={14}
                className="mt-1"
              />
            </div>

            <div>
              <Label htmlFor="posto_graduacao" className="text-gray-700 font-semibold">
                Posto/Graduação
              </Label>
              <Input
                id="posto_graduacao"
                value={dados.posto_graduacao}
                onChange={(e) => setDados({ ...dados, posto_graduacao: e.target.value })}
                placeholder="Ex: Agente, Inspetor..."
                className="mt-1"
              />
            </div>

            <div>
              <Label htmlFor="unidade" className="text-gray-700 font-semibold">
                Unidade de Lotação
              </Label>
              <Input
                id="unidade"
                value={dados.unidade}
                onChange={(e) => setDados({ ...dados, unidade: e.target.value })}
                placeholder="Ex: PRF/SP"
                className="mt-1"
              />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Bottom Actions */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t p-4">
        <Button
          onClick={handleSalvar}
          disabled={!dados.nome_completo || !dados.matricula}
          className="w-full bg-blue-900 hover:bg-blue-800 text-yellow-400"
        >
          <Save className="w-5 h-5 mr-2" />
          Salvar Dados
        </Button>
      </div>
    </div>
  );
}