import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { createPageUrl } from '../utils';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, FileText, Search, Calendar, User, Trash2, MessageCircle, Download, Edit } from 'lucide-react';
import { format } from 'date-fns';
import { generateTCOPDF, generateDeclaracaoPDF, generateCompromissoPDF } from '../components/ocorrencia/PDFGenerator';
import { exportarParaWhatsApp } from '../components/ocorrencia/ExportWhatsApp';
import { formatarCPF } from '@/components/utils/formatters';

export default function Historico() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [searchTerm, setSearchTerm] = useState('');

  const { data: ocorrencias = [], isLoading } = useQuery({
    queryKey: ['ocorrencias'],
    queryFn: () => base44.entities.Ocorrencia.list('-created_date'),
  });

  const filteredOcorrencias = ocorrencias.filter(occ => 
    occ.numero.toLowerCase().includes(searchTerm.toLowerCase()) ||
    occ.nome_autor.toLowerCase().includes(searchTerm.toLowerCase()) ||
    occ.cpf.includes(searchTerm)
  );

  const handleRegeneratePDF = async (ocorrencia) => {
    await generateTCOPDF(ocorrencia);
  };

  const handleExportIndividualPDFs = async (ocorrencia) => {
    await generateDeclaracaoPDF(ocorrencia);
    await generateCompromissoPDF(ocorrencia);
  };

  const handleExportWhatsApp = (ocorrencia) => {
    exportarParaWhatsApp(ocorrencia);
  };

  const handleEditOcorrencia = (ocorrencia) => {
    navigate(createPageUrl('Qualificacao'), { state: { ocorrencia } });
  };

  const deleteOcorrenciaMutation = useMutation({
    mutationFn: (id) => base44.entities.Ocorrencia.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['ocorrencias'] });
    },
  });

  const handleDelete = async (id) => {
    if (window.confirm('Tem certeza que deseja excluir esta ocorrência?')) {
      deleteOcorrenciaMutation.mutate(id);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 via-blue-800 to-blue-900 p-3 sm:p-6">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center gap-2 sm:gap-4 mb-4 sm:mb-6">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate(createPageUrl('Home'))}
            className="text-white hover:bg-white/20 min-w-[44px] min-h-[44px] touch-manipulation"
          >
            <ArrowLeft className="w-6 h-6" />
          </Button>
          <h1 className="text-xl sm:text-2xl md:text-3xl font-bold text-yellow-400 leading-tight">Histórico de Ocorrências</h1>
        </div>

        <div className="mb-4 sm:mb-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500 w-5 h-5" />
            <Input
              placeholder="Buscar por número, nome ou CPF..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 h-12 text-base bg-white/95"
            />
          </div>
        </div>

        {isLoading ? (
          <div className="text-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-yellow-400 mx-auto"></div>
            <p className="mt-4 text-yellow-100">Carregando...</p>
          </div>
        ) : filteredOcorrencias.length === 0 ? (
          <Card className="bg-white/95">
            <CardContent className="py-12 text-center">
              <FileText className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-600 mb-2">
                {searchTerm ? 'Nenhuma ocorrência encontrada' : 'Nenhuma ocorrência registrada'}
              </h3>
              <p className="text-gray-500">
                {searchTerm ? 'Tente outra busca' : 'Crie sua primeira ocorrência'}
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-3 sm:space-y-4">
            {filteredOcorrencias.map((ocorrencia) => (
              <Card key={ocorrencia.id} className="hover:shadow-lg transition-shadow bg-white/95">
                <CardContent className="p-4 sm:p-6">
                  <div className="flex flex-col sm:flex-row items-start justify-between gap-4">
                    <div className="flex-1 w-full">
                      <div className="flex flex-wrap items-center gap-2 mb-3">
                        <h3 className="text-base sm:text-lg md:text-xl font-bold text-blue-900 leading-tight">
                          TCO {ocorrencia.numero ? `Nº ${ocorrencia.numero}` : 'sem número'}
                        </h3>
                        <Badge variant={ocorrencia.status === 'finalizado' ? 'default' : 'secondary'} className="bg-blue-900 text-white text-xs sm:text-sm">
                          {ocorrencia.status === 'finalizado' ? 'Finalizado' : 'Rascunho'}
                        </Badge>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 sm:gap-4 text-sm sm:text-base">
                        <div className="flex items-center gap-2 text-gray-700">
                          <User className="w-4 h-4 flex-shrink-0" />
                          <span className="font-semibold">Autor:</span>
                          <span className="break-words">{ocorrencia.nome_autor}</span>
                        </div>
                        <div className="flex items-center gap-2 text-gray-700">
                          <span className="font-semibold">CPF:</span>
                          <span>{formatarCPF(ocorrencia.cpf_autor)}</span>
                        </div>
                        <div className="flex items-center gap-2 text-gray-700">
                          <span className="font-semibold">Comarca:</span>
                          <span className="break-words">{ocorrencia.comarca}</span>
                        </div>
                        <div className="flex items-center gap-2 text-gray-700">
                          <Calendar className="w-4 h-4 flex-shrink-0" />
                          <span>{format(new Date(ocorrencia.created_date), 'dd/MM/yyyy HH:mm')}</span>
                        </div>
                      </div>

                      <div className="mt-3 text-sm sm:text-base text-gray-700">
                        <span className="font-semibold">PRF:</span> {ocorrencia.nome_prf} ({ocorrencia.matricula})
                      </div>
                    </div>

                    <div className="flex flex-col gap-2 w-full sm:w-auto">
                      <div className="flex flex-row gap-2">
                        <Button
                          onClick={() => handleEditOcorrencia(ocorrencia)}
                          variant="outline"
                          className="flex-1 sm:flex-initial min-h-[48px] font-semibold touch-manipulation border-blue-900 text-blue-900 hover:bg-blue-50"
                        >
                          <Edit className="w-5 h-5 sm:mr-2" />
                          <span className="hidden sm:inline">Editar</span>
                        </Button>
                        <Button
                          onClick={() => handleExportIndividualPDFs(ocorrencia)}
                          className="flex-1 sm:flex-initial bg-blue-900 hover:bg-blue-800 text-yellow-400 min-h-[48px] font-semibold touch-manipulation"
                        >
                          <Download className="w-5 h-5 sm:mr-2" />
                          <span className="hidden sm:inline">PDFs TCO</span>
                        </Button>
                        <Button
                          onClick={() => handleRegeneratePDF(ocorrencia)}
                          variant="outline"
                          className="flex-1 sm:flex-initial min-h-[48px] font-semibold touch-manipulation"
                        >
                          <FileText className="w-5 h-5 sm:mr-2" />
                          <span className="hidden sm:inline">Todos PDF</span>
                        </Button>
                      </div>
                      <div className="flex flex-row gap-2">
                        <Button
                          onClick={() => handleExportWhatsApp(ocorrencia)}
                          variant="secondary"
                          className="flex-1 sm:flex-initial bg-green-600 hover:bg-green-700 text-white min-h-[48px] font-semibold touch-manipulation"
                        >
                          <MessageCircle className="w-5 h-5 sm:mr-2" />
                          <span className="hidden sm:inline">WhatsApp</span>
                        </Button>
                        <Button
                          variant="destructive"
                          onClick={() => handleDelete(ocorrencia.id)}
                          className="flex-1 sm:flex-initial min-h-[48px] font-semibold touch-manipulation"
                        >
                          <Trash2 className="w-5 h-5 sm:mr-2" />
                          <span className="hidden sm:inline">Excluir</span>
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}