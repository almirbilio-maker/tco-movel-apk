import React from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '../utils';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ArrowLeft, Info } from 'lucide-react';

export default function Configuracoes() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center gap-4 mb-6">
          <Button
            variant="ghost"
            onClick={() => navigate(createPageUrl('Home'))}>

            <ArrowLeft className="w-5 h-5" />
          </Button>
          <h1 className="text-3xl font-bold text-gray-900">Configurações</h1>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Info className="w-5 h-5" />
              Informações do Sistema
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="border-b pb-3">
              <p className="text-sm text-gray-600 mb-1">Versão</p>
              <p className="font-semibold">1.0.0</p>
            </div>

            <div className="border-b pb-3">
              <p className="text-sm text-gray-600 mb-1">Modo de Operação</p>
              <p className="font-semibold text-green-600">Sistema Online com Dados Locais</p>
            </div>

            




            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <h3 className="font-semibold text-blue-900 mb-2">Sobre o TCO Manager</h3>
              <p className="text-sm text-blue-800">
                Aplicativo offline destinado à gestão, organização e geração automatizada de documentos de apoio relacionados a Termos Circunstanciados de Ocorrência (TCO), desenvolvido em estrita conformidade com a legislação brasileira vigente, garantindo segurança, padronização e eficiência nos procedimentos.
              </p>
              <p className="text-xs text-blue-700 mt-2">
                © Almir Bílio de Alencar
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>);

}