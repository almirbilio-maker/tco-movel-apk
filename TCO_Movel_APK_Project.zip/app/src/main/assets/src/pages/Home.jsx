import React, { useState, useMemo } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Plus, Calendar, MapPin, FileText, Trash2, Search, X } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from '../utils';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import ConfirmacaoExclusao from '../components/ocorrencia/ConfirmacaoExclusao';

export default function Home() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('pendentes');
  const [ocorrenciaParaExcluir, setOcorrenciaParaExcluir] = useState(null);
  const [swipedId, setSwipedId] = useState(null);
  const [mostrarFiltros, setMostrarFiltros] = useState(false);
  const [filtros, setFiltros] = useState({
    dataInicio: '',
    dataFim: '',
    policial: '',
    status: ''
  });
  const queryClient = useQueryClient();

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Ocorrencia.create(data),
    onSuccess: (result) => {
      queryClient.invalidateQueries({ queryKey: ['ocorrencias'] });
      navigate(createPageUrl('NovaOcorrencia') + `?id=${result.id}`);
    },
  });

  const handleNovaOcorrencia = () => {
    const novaOcorrencia = {
      numero_tco: '',
      local: '',
      data: '',
      comarca: '',
      policial_responsavel: '',
      matricula_policial: '',
      envolvidos: [],
      veiculo: {},
      assinaturas: {},
      status: 'pendente'
    };
    createMutation.mutate(novaOcorrencia);
  };

  const { data: ocorrencias = [], isLoading } = useQuery({
    queryKey: ['ocorrencias'],
    queryFn: () => base44.entities.Ocorrencia.list()
  });

  const ocorrenciasFiltradas = useMemo(() => {
    return ocorrencias.filter((occ) => {
      // Filtro por data de início
      if (filtros.dataInicio && occ.data) {
        if (new Date(occ.data) < new Date(filtros.dataInicio)) return false;
      }

      // Filtro por data fim
      if (filtros.dataFim && occ.data) {
        if (new Date(occ.data) > new Date(filtros.dataFim)) return false;
      }

      // Filtro por policial
      if (filtros.policial && occ.policial_responsavel) {
        if (!occ.policial_responsavel.toLowerCase().includes(filtros.policial.toLowerCase())) return false;
      }

      // Filtro por status
      if (filtros.status && occ.status !== filtros.status) return false;

      return true;
    });
  }, [ocorrencias, filtros]);

  const pendentes = useMemo(() => ocorrenciasFiltradas.filter((o) => o.status === 'pendente'), [ocorrenciasFiltradas]);
  const finalizadas = useMemo(() => ocorrenciasFiltradas.filter((o) => o.status === 'finalizada'), [ocorrenciasFiltradas]);

  const limparFiltros = () => {
    setFiltros({
      dataInicio: '',
      dataFim: '',
      policial: '',
      status: ''
    });
  };

  const temFiltrosAtivos = filtros.dataInicio || filtros.dataFim || filtros.policial || filtros.status;

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Ocorrencia.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['ocorrencias'] });
      setOcorrenciaParaExcluir(null);
      setSwipedId(null);
    }
  });

  const handleExcluir = (ocorrencia, e) => {
    if (e) {
      e.preventDefault();
      e.stopPropagation();
    }
    setOcorrenciaParaExcluir(ocorrencia);
  };

  const confirmarExclusao = () => {
    if (ocorrenciaParaExcluir) {
      deleteMutation.mutate(ocorrenciaParaExcluir.id);
    }
  };

  const OcorrenciaCard = React.memo(({ ocorrencia }) => {
    const [touchStart, setTouchStart] = useState(0);
    const [touchEnd, setTouchEnd] = useState(0);
    const [isSwiping, setIsSwiping] = useState(false);

    const handleTouchStart = (e) => {
      setTouchStart(e.targetTouches[0].clientX);
    };

    const handleTouchMove = (e) => {
      setTouchEnd(e.targetTouches[0].clientX);
      const diff = touchStart - e.targetTouches[0].clientX;
      if (diff > 10) {
        setIsSwiping(true);
      }
    };

    const handleTouchEnd = () => {
      if (!isSwiping) return;

      const diff = touchStart - touchEnd;
      if (diff > 75) {
        setSwipedId(ocorrencia.id);
      } else {
        setSwipedId(null);
      }
      setIsSwiping(false);
      setTouchEnd(0);
    };

    const isSwipedOpen = swipedId === ocorrencia.id;

    return (
      <div className="relative overflow-hidden">
        <div
          className={`transition-transform duration-300 ${
          isSwipedOpen ? '-translate-x-20' : 'translate-x-0'}`
          }
          onTouchStart={handleTouchStart}
          onTouchMove={handleTouchMove}
          onTouchEnd={handleTouchEnd}>

          <Link
            to={createPageUrl('NovaOcorrencia') + `?id=${ocorrencia.id}`}
            onClick={(e) => {
              if (isSwipedOpen) {
                e.preventDefault();
                setSwipedId(null);
              }
            }}>

            <Card className="hover:shadow-lg transition-shadow bg-white/95 border-l-4 border-l-yellow-400">
              <CardContent className="p-4">
                <div className="flex items-start justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <FileText className="w-5 h-5 text-blue-900" />
                    <h3 className="font-bold text-blue-900">TCO {ocorrencia.numero_tco}</h3>
                  </div>
                  {ocorrencia.status === 'pendente' &&
                  <span className="text-xs bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full font-medium">
                      Pendente
                    </span>
                  }
                  {ocorrencia.status === 'finalizada' &&
                  <span className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded-full font-medium">
                      Finalizada
                    </span>
                  }
                </div>
                
                <div className="space-y-1 text-sm text-gray-700">
                  <div className="flex items-center gap-2">
                    <MapPin className="w-4 h-4 text-gray-500" />
                    <span>{ocorrencia.local}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-gray-500" />
                    <span>
                      {ocorrencia.data && format(new Date(ocorrencia.data), "dd 'de' MMMM 'de' yyyy", { locale: ptBR })}
                    </span>
                  </div>
                  {ocorrencia.policial_responsavel &&
                  <div className="text-xs text-gray-600 mt-2">
                      Responsável: {ocorrencia.policial_responsavel}
                    </div>
                  }
                </div>
              </CardContent>
            </Card>
          </Link>
        </div>
        
        {/* Botão de exclusão revelado pelo swipe */}
        <button
          onClick={(e) => handleExcluir(ocorrencia, e)}
          className="absolute right-0 top-0 bottom-0 w-20 bg-red-600 hover:bg-red-700 flex items-center justify-center transition-colors">

          <Trash2 className="w-6 h-6 text-white" />
        </button>
      </div>
    );
  });

  return (
    <div className="min-h-screen pb-24">
      {/* Header com busca */}
      <div className="bg-blue-950 px-4 pt-4 pb-0">
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-lg font-bold text-yellow-400">Histórico de Ocorrências</h2>
          <Button
            onClick={() => setMostrarFiltros(!mostrarFiltros)}
            variant="ghost"
            size="sm"
            className="text-yellow-400 hover:text-yellow-300 hover:bg-blue-800">

            <Search className="w-5 h-5" />
          </Button>
        </div>

        {/* Painel de Filtros */}
        {mostrarFiltros &&
        <Card className="mb-3 bg-blue-900/50 border-blue-700">
            <CardContent className="p-3 space-y-3">
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-sm font-semibold text-yellow-400">Filtros</h3>
                {temFiltrosAtivos &&
              <Button
                onClick={limparFiltros}
                variant="ghost"
                size="sm"
                className="text-xs text-yellow-300 hover:text-yellow-400 h-auto py-1">

                    Limpar filtros
                  </Button>
              }
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-xs text-blue-200 mb-1 block">Data Início</label>
                  <Input
                  type="date"
                  value={filtros.dataInicio}
                  onChange={(e) => setFiltros({ ...filtros, dataInicio: e.target.value })}
                  className="bg-blue-800 border-blue-600 text-white text-sm h-9" />

                </div>
                <div>
                  <label className="text-xs text-blue-200 mb-1 block">Data Fim</label>
                  <Input
                  type="date"
                  value={filtros.dataFim}
                  onChange={(e) => setFiltros({ ...filtros, dataFim: e.target.value })}
                  className="bg-blue-800 border-blue-600 text-white text-sm h-9" />

                </div>
              </div>

              <div>
                <label className="text-xs text-blue-200 mb-1 block">Policial Responsável</label>
                <Input
                type="text"
                placeholder="Buscar por nome..."
                value={filtros.policial}
                onChange={(e) => setFiltros({ ...filtros, policial: e.target.value })}
                className="bg-blue-800 border-blue-600 text-white placeholder:text-blue-400 text-sm h-9" />

              </div>

              <div>
                <label className="text-xs text-blue-200 mb-1 block">Status</label>
                <select
                value={filtros.status}
                onChange={(e) => setFiltros({ ...filtros, status: e.target.value })}
                className="w-full bg-blue-800 border border-blue-600 text-white rounded-md px-3 py-2 text-sm h-9">

                  <option value="">Todos</option>
                  <option value="pendente">Pendente</option>
                  <option value="finalizada">Finalizada</option>
                </select>
              </div>

              {temFiltrosAtivos &&
            <div className="text-xs text-blue-300 pt-1">
                  {ocorrenciasFiltradas.length} ocorrência(s) encontrada(s)
                </div>
            }
            </CardContent>
          </Card>
        }

        {/* Tabs */}
        <div className="flex border-b border-blue-800">
          <button
            onClick={() => setActiveTab('pendentes')}
            className={`flex-1 py-3 font-semibold transition-colors ${
            activeTab === 'pendentes' ?
            'text-yellow-400 border-b-2 border-yellow-400' :
            'text-blue-300 hover:text-yellow-300'}`
            }>

            Pendentes ({pendentes.length})
          </button>
          <button
            onClick={() => setActiveTab('finalizadas')}
            className={`flex-1 py-3 font-semibold transition-colors ${
              activeTab === 'finalizadas'
                ? 'text-yellow-400 border-b-2 border-yellow-400'
                : 'text-blue-300 hover:text-yellow-300'
            }`}
          >

            Finalizadas ({finalizadas.length})
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="p-4">
        {isLoading ?
        <div className="text-center py-12 text-yellow-100">Carregando...</div> :

        <div className="space-y-3">
            {activeTab === 'pendentes' ?
          pendentes.length > 0 ?
          pendentes.map((occ) => <OcorrenciaCard key={occ.id} ocorrencia={occ} />) :

          <div className="text-center py-12 text-yellow-100">
                  Nenhuma ocorrência pendente
                </div> :


          finalizadas.length > 0 ?
          finalizadas.map((occ) => <OcorrenciaCard key={occ.id} ocorrencia={occ} />) :

          <div className="text-center py-12 text-yellow-100">
                  Nenhuma ocorrência finalizada
                </div>

          }
          </div>
        }
      </div>

      {/* Floating Action Button */}
      <Button
        onClick={handleNovaOcorrencia}
        disabled={createMutation.isPending}
        className="fixed bottom-6 right-6 w-14 h-14 rounded-full shadow-2xl bg-yellow-400 hover:bg-yellow-500 text-blue-900 p-0 z-30">

        <Plus className="w-6 h-6" />
      </Button>

      <ConfirmacaoExclusao
        open={!!ocorrenciaParaExcluir}
        onOpenChange={(open) => !open && setOcorrenciaParaExcluir(null)}
        onConfirm={confirmarExclusao}
        numeroTCO={ocorrenciaParaExcluir?.numero_tco} />

    </div>);

}