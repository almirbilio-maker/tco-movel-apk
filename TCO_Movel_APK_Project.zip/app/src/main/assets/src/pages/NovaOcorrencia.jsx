import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '../utils';
import { Button } from '@/components/ui/button';
import { ArrowLeft, Save, CheckCircle } from 'lucide-react';
import DadosGeraisTab from '../components/ocorrencia/DadosGeraisTab';
import EnvolvidosTab from '../components/ocorrencia/EnvolvidosTab';
import VeiculoTab from '../components/ocorrencia/VeiculoTab';
import AssinaturasTab from '../components/ocorrencia/AssinaturasTab';
import ExportacaoTab from '../components/ocorrencia/ExportacaoTab';

export default function NovaOcorrencia() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const urlParams = new URLSearchParams(window.location.search);
  const ocorrenciaId = urlParams.get('id');

  const [activeTab, setActiveTab] = useState(0);
  const [dados, setDados] = useState({
    numero_tco: '',
    local: '',
    data: new Date().toISOString().split('T')[0],
    comarca: '',
    policial_responsavel: '',
    matricula_policial: '',
    envolvidos: [],
    veiculo: {},
    assinaturas: {},
    status: 'pendente'
  });

  const { data: operador } = useQuery({
    queryKey: ['operador'],
    queryFn: async () => {
      const lista = await base44.entities.Operador.list();
      return lista[0] || null;
    },
  });

  const { data: ocorrenciaExistente } = useQuery({
    queryKey: ['ocorrencia', ocorrenciaId],
    queryFn: async () => {
      if (!ocorrenciaId) return null;
      const lista = await base44.entities.Ocorrencia.filter({ id: ocorrenciaId });
      return lista[0] || null;
    },
    enabled: !!ocorrenciaId,
  });

  // Carregar dados apenas na primeira abertura
  useEffect(() => {
    if (ocorrenciaExistente) {
      setDados(ocorrenciaExistente);
    }
  }, [ocorrenciaExistente]);

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Ocorrencia.create(data),
    onSuccess: (result) => {
      queryClient.invalidateQueries({ queryKey: ['ocorrencias'] });
      const novaUrl = window.location.pathname + '?id=' + result.id;
      window.history.replaceState(null, '', novaUrl);
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Ocorrencia.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['ocorrencias'] });
      queryClient.invalidateQueries({ queryKey: ['ocorrencia', ocorrenciaId] });
    },
  });



  useEffect(() => {
    const autoSave = setTimeout(() => {
      if (ocorrenciaId) {
        updateMutation.mutate({ id: ocorrenciaId, data: dados });
      } else if (!ocorrenciaId && dados.numero_tco && dados.local && dados.data) {
        createMutation.mutate(dados);
      }
    }, 2000);

    return () => clearTimeout(autoSave);
  }, [dados]);

  const handleDadosChange = (novoDados) => {
    setDados({ ...dados, ...novoDados });
  };

  const finalizarOcorrencia = async () => {
    try {
      const dadosFinalizados = { ...dados, status: 'finalizada' };
      
      if (ocorrenciaId) {
        await updateMutation.mutateAsync({ id: ocorrenciaId, data: dadosFinalizados });
      } else {
        const resultado = await createMutation.mutateAsync(dadosFinalizados);
      }
      
      // Aguarda um pouco para garantir sincronização antes de navegar
      await new Promise(resolve => setTimeout(resolve, 500));
      navigate(createPageUrl('Home'));
    } catch (error) {
      console.error('Erro ao finalizar ocorrência:', error);
    }
  };



  const tabs = [
    { label: 'Dados Gerais', component: DadosGeraisTab },
    { label: 'Envolvidos', component: EnvolvidosTab },
    { label: 'Veículo', component: VeiculoTab },
    { label: 'Assinaturas', component: AssinaturasTab, passOcorrencia: true },
    { label: 'Exportação', component: ExportacaoTab }
  ];

  const TabComponent = tabs[activeTab].component;

  return (
    <div className="min-h-screen pb-24">
      {/* Header */}
      <div className="bg-blue-950 px-4 py-3 flex items-center gap-3 border-b border-blue-800">
        <button
          onClick={() => navigate(createPageUrl('Home'))}
          className="p-2 hover:bg-blue-800 rounded-lg transition-colors"
        >
          <ArrowLeft className="w-5 h-5 text-yellow-400" />
        </button>
        <h1 className="text-lg font-bold text-yellow-400 flex-1">
          {ocorrenciaId ? 'Editar Ocorrência' : 'Nova Ocorrência'}
        </h1>
      </div>

      {/* Tabs */}
      <div className="bg-white border-b overflow-x-auto">
        <div className="flex min-w-max">
          {tabs.map((tab, index) => (
            <button
              key={index}
              onClick={() => setActiveTab(index)}
              className={`flex-1 px-4 py-3 font-semibold text-sm transition-colors whitespace-nowrap ${
                activeTab === index
                  ? 'text-blue-900 border-b-2 border-blue-900 bg-blue-50'
                  : 'text-gray-600 hover:text-blue-900 hover:bg-gray-50'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Tab Content */}
      <div className="bg-gray-50 min-h-[calc(100vh-200px)]">
        {activeTab === 0 && (
          <TabComponent
            dados={dados}
            onChange={handleDadosChange}
            operador={operador}
          />
        )}
        {activeTab === 1 && (
          <TabComponent
            envolvidos={dados.envolvidos}
            onChange={(envolvidos) => setDados({ ...dados, envolvidos })}
          />
        )}
        {activeTab === 2 && (
          <TabComponent
            veiculo={dados.veiculo}
            onChange={(veiculo) => setDados({ ...dados, veiculo })}
          />
        )}
        {activeTab === 3 && (
          <TabComponent
            ocorrencia={dados}
            onChange={(novoDados) => setDados({ ...dados, ...novoDados })}
          />
        )}
        {activeTab === 4 && (
          <TabComponent
            ocorrencia={dados}
          />
        )}
      </div>

      {/* Bottom Actions */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t p-4 shadow-lg">
        <Button
            onClick={finalizarOcorrencia}
            className="w-full bg-green-600 hover:bg-green-700 text-white py-6 text-base font-semibold"
            disabled={!ocorrenciaId}
          >
            <CheckCircle className="w-5 h-5 mr-2" />
            Finalizar Ocorrência
          </Button>
      </div>
    </div>
  );
}