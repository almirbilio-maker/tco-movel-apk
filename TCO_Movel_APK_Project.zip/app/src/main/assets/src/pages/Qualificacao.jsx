import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { createPageUrl } from '../utils';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ArrowLeft, ArrowRight } from 'lucide-react';

export default function Qualificacao() {
  const navigate = useNavigate();
  const location = useLocation();
  const tcoData = location.state || {};
  const editingOcorrencia = tcoData.ocorrencia;

  const [autor, setAutor] = useState({
    nome_autor: editingOcorrencia?.nome_autor || '',
    cpf_autor: editingOcorrencia?.cpf_autor || '',
    telefone_autor: editingOcorrencia?.telefone_autor || '',
    naturalidade_autor: editingOcorrencia?.naturalidade_autor || '',
    nacionalidade_autor: editingOcorrencia?.nacionalidade_autor || 'Brasileira',
    sexo_autor: editingOcorrencia?.sexo_autor || '',
    data_nascimento_autor: editingOcorrencia?.data_nascimento_autor || '',
    estado_civil_autor: editingOcorrencia?.estado_civil_autor || '',
    profissao_autor: editingOcorrencia?.profissao_autor || '',
    escolaridade_autor: editingOcorrencia?.escolaridade_autor || '',
    etnia_autor: editingOcorrencia?.etnia_autor || '',
    identidade_genero_autor: editingOcorrencia?.identidade_genero_autor || '',
    orientacao_sexual_autor: editingOcorrencia?.orientacao_sexual_autor || '',
    logradouro_autor: editingOcorrencia?.logradouro_autor || '',
    numero_endereco_autor: editingOcorrencia?.numero_endereco_autor || '',
    bairro_autor: editingOcorrencia?.bairro_autor || '',
    ponto_referencia_autor: editingOcorrencia?.ponto_referencia_autor || '',
    municipio_autor: editingOcorrencia?.municipio_autor || '',
  });

  const [testemunha, setTestemunha] = useState({
    tem_testemunha: editingOcorrencia?.tem_testemunha || false,
    nome_testemunha: editingOcorrencia?.nome_testemunha || '',
    cpf_testemunha: editingOcorrencia?.cpf_testemunha || '',
    telefone_testemunha: editingOcorrencia?.telefone_testemunha || '',
    naturalidade_testemunha: editingOcorrencia?.naturalidade_testemunha || '',
    nacionalidade_testemunha: editingOcorrencia?.nacionalidade_testemunha || 'Brasileira',
    sexo_testemunha: editingOcorrencia?.sexo_testemunha || '',
    data_nascimento_testemunha: editingOcorrencia?.data_nascimento_testemunha || '',
    estado_civil_testemunha: editingOcorrencia?.estado_civil_testemunha || '',
    profissao_testemunha: editingOcorrencia?.profissao_testemunha || '',
    escolaridade_testemunha: editingOcorrencia?.escolaridade_testemunha || '',
    etnia_testemunha: editingOcorrencia?.etnia_testemunha || '',
    identidade_genero_testemunha: editingOcorrencia?.identidade_genero_testemunha || '',
    orientacao_sexual_testemunha: editingOcorrencia?.orientacao_sexual_testemunha || '',
    logradouro_testemunha: editingOcorrencia?.logradouro_testemunha || '',
    numero_endereco_testemunha: editingOcorrencia?.numero_endereco_testemunha || '',
    bairro_testemunha: editingOcorrencia?.bairro_testemunha || '',
    ponto_referencia_testemunha: editingOcorrencia?.ponto_referencia_testemunha || '',
    municipio_testemunha: editingOcorrencia?.municipio_testemunha || '',
  });

  const [errors, setErrors] = useState({});

  const formatPhone = (value) => {
    const numbers = value.replace(/\D/g, '');
    if (numbers.length <= 11) {
      return numbers.replace(/(\d{2})(\d{5})(\d{4})/, '($1)$2-$3');
    }
    return value;
  };

  const handleAutorChange = (field, value) => {
    if (field === 'telefone_autor') {
      value = formatPhone(value);
    }
    setAutor(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const handleTestemunhaChange = (field, value) => {
    if (field === 'telefone_testemunha') {
      value = formatPhone(value);
    }
    setTestemunha(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const validateForm = () => {
    const newErrors = {};
    
    if (!autor.nome_autor.trim()) newErrors.nome_autor = 'Nome obrigatório';
    if (!autor.cpf_autor.trim()) newErrors.cpf_autor = 'CPF obrigatório';
    if (!autor.telefone_autor.trim()) newErrors.telefone_autor = 'Telefone obrigatório';

    if (testemunha.tem_testemunha) {
      if (!testemunha.nome_testemunha.trim()) newErrors.nome_testemunha = 'Nome obrigatório';
      if (!testemunha.cpf_testemunha.trim()) newErrors.cpf_testemunha = 'CPF obrigatório';
      if (!testemunha.telefone_testemunha.trim()) newErrors.telefone_testemunha = 'Telefone obrigatório';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleContinue = () => {
    if (!validateForm()) return;
    
    navigate(createPageUrl('NovaOcorrencia'), {
      state: {
        ...tcoData,
        ...(editingOcorrencia && { ocorrencia: editingOcorrencia }),
        ...autor,
        ...testemunha
      }
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 via-blue-800 to-blue-900 p-3 sm:p-4">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center gap-2 mb-4 sm:mb-6">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate(createPageUrl('Home'))}
            className="text-white hover:bg-white/20 min-w-[44px] min-h-[44px] touch-manipulation"
          >
            <ArrowLeft className="w-6 h-6" />
          </Button>
          <h1 className="text-xl sm:text-2xl md:text-3xl font-bold text-yellow-400 leading-tight">
            {editingOcorrencia ? 'Editar Qualificação' : 'Qualificação dos Envolvidos'}
          </h1>
        </div>

        <Tabs defaultValue="autor" className="w-full">
          <TabsList className="grid w-full grid-cols-2 bg-blue-950/50 h-12 sm:h-10">
            <TabsTrigger value="autor" className="data-[state=active]:bg-yellow-400 data-[state=active]:text-blue-900 text-base sm:text-sm font-semibold text-yellow-100">
              Autor
            </TabsTrigger>
            <TabsTrigger value="testemunha" className="data-[state=active]:bg-yellow-400 data-[state=active]:text-blue-900 text-base sm:text-sm font-semibold text-yellow-100">
              Testemunha
            </TabsTrigger>
          </TabsList>

          <TabsContent value="autor" className="mt-4 sm:mt-5">
            <Card className="bg-white/95 shadow-lg">
              <CardHeader className="pb-4">
                <CardTitle className="text-blue-900 text-lg sm:text-xl">Dados do Autor</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4 sm:space-y-5">
                <div>
                  <Label htmlFor="nome_autor" className="text-blue-900 font-semibold text-sm sm:text-base mb-2 block">Nome Completo *</Label>
                  <Input
                    id="nome_autor"
                    value={autor.nome_autor}
                    onChange={(e) => handleAutorChange('nome_autor', e.target.value)}
                    className={`h-11 sm:h-10 text-base ${errors.nome_autor ? 'border-red-500' : ''}`}
                  />
                  {errors.nome_autor && <p className="text-red-600 text-sm mt-1.5 font-medium">{errors.nome_autor}</p>}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-5">
                  <div>
                    <Label htmlFor="cpf_autor" className="text-blue-900 font-semibold text-sm sm:text-base mb-2 block">CPF *</Label>
                    <Input
                      id="cpf_autor"
                      value={autor.cpf_autor}
                      onChange={(e) => handleAutorChange('cpf_autor', e.target.value)}
                      placeholder="000.000.000-00"
                      className={`h-11 sm:h-10 text-base ${errors.cpf_autor ? 'border-red-500' : ''}`}
                    />
                    {errors.cpf_autor && <p className="text-red-600 text-sm mt-1.5 font-medium">{errors.cpf_autor}</p>}
                  </div>

                  <div>
                    <Label htmlFor="telefone_autor" className="text-blue-900 font-semibold text-sm sm:text-base mb-2 block">Telefone Celular *</Label>
                    <Input
                      id="telefone_autor"
                      value={autor.telefone_autor}
                      onChange={(e) => handleAutorChange('telefone_autor', e.target.value)}
                      placeholder="(00)00000-0000"
                      className={`h-11 sm:h-10 text-base ${errors.telefone_autor ? 'border-red-500' : ''}`}
                    />
                    {errors.telefone_autor && <p className="text-red-600 text-sm mt-1.5 font-medium">{errors.telefone_autor}</p>}
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="naturalidade_autor" className="text-blue-900">Naturalidade</Label>
                    <Input
                      id="naturalidade_autor"
                      value={autor.naturalidade_autor}
                      onChange={(e) => handleAutorChange('naturalidade_autor', e.target.value)}
                    />
                  </div>

                  <div>
                    <Label htmlFor="nacionalidade_autor" className="text-blue-900">Nacionalidade</Label>
                    <Input
                      id="nacionalidade_autor"
                      value={autor.nacionalidade_autor}
                      onChange={(e) => handleAutorChange('nacionalidade_autor', e.target.value)}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="sexo_autor" className="text-blue-900">Sexo</Label>
                    <Input
                      id="sexo_autor"
                      value={autor.sexo_autor}
                      onChange={(e) => handleAutorChange('sexo_autor', e.target.value)}
                    />
                  </div>

                  <div>
                    <Label htmlFor="data_nascimento_autor" className="text-blue-900">Data de Nascimento</Label>
                    <Input
                      id="data_nascimento_autor"
                      type="date"
                      value={autor.data_nascimento_autor}
                      onChange={(e) => handleAutorChange('data_nascimento_autor', e.target.value)}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="estado_civil_autor" className="text-blue-900">Estado Civil</Label>
                    <Input
                      id="estado_civil_autor"
                      value={autor.estado_civil_autor}
                      onChange={(e) => handleAutorChange('estado_civil_autor', e.target.value)}
                    />
                  </div>

                  <div>
                    <Label htmlFor="profissao_autor" className="text-blue-900">Profissão</Label>
                    <Input
                      id="profissao_autor"
                      value={autor.profissao_autor}
                      onChange={(e) => handleAutorChange('profissao_autor', e.target.value)}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <Label htmlFor="escolaridade_autor" className="text-blue-900">Escolaridade</Label>
                    <Input
                      id="escolaridade_autor"
                      value={autor.escolaridade_autor}
                      onChange={(e) => handleAutorChange('escolaridade_autor', e.target.value)}
                    />
                  </div>

                  <div>
                    <Label htmlFor="etnia_autor" className="text-blue-900">Etnia</Label>
                    <Input
                      id="etnia_autor"
                      value={autor.etnia_autor}
                      onChange={(e) => handleAutorChange('etnia_autor', e.target.value)}
                    />
                  </div>

                  <div>
                    <Label htmlFor="identidade_genero_autor" className="text-blue-900">Identidade de Gênero</Label>
                    <Input
                      id="identidade_genero_autor"
                      value={autor.identidade_genero_autor}
                      onChange={(e) => handleAutorChange('identidade_genero_autor', e.target.value)}
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="orientacao_sexual_autor" className="text-blue-900">Orientação Sexual</Label>
                  <Input
                    id="orientacao_sexual_autor"
                    value={autor.orientacao_sexual_autor}
                    onChange={(e) => handleAutorChange('orientacao_sexual_autor', e.target.value)}
                  />
                </div>

                <div className="border-t pt-4 mt-4">
                  <h3 className="font-semibold mb-3 text-blue-900">Endereço Residencial</h3>
                  
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-4">
                    <div className="sm:col-span-2">
                      <Label htmlFor="logradouro_autor" className="text-blue-900">Logradouro</Label>
                      <Input
                        id="logradouro_autor"
                        value={autor.logradouro_autor}
                        onChange={(e) => handleAutorChange('logradouro_autor', e.target.value)}
                      />
                    </div>

                    <div>
                      <Label htmlFor="numero_endereco_autor" className="text-blue-900">Número</Label>
                      <Input
                        id="numero_endereco_autor"
                        value={autor.numero_endereco_autor}
                        onChange={(e) => handleAutorChange('numero_endereco_autor', e.target.value)}
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="bairro_autor" className="text-blue-900">Bairro</Label>
                      <Input
                        id="bairro_autor"
                        value={autor.bairro_autor}
                        onChange={(e) => handleAutorChange('bairro_autor', e.target.value)}
                      />
                    </div>

                    <div>
                      <Label htmlFor="municipio_autor" className="text-blue-900">Município</Label>
                      <Input
                        id="municipio_autor"
                        value={autor.municipio_autor}
                        onChange={(e) => handleAutorChange('municipio_autor', e.target.value)}
                      />
                    </div>
                  </div>

                  <div className="mt-4">
                    <Label htmlFor="ponto_referencia_autor" className="text-blue-900">Ponto de Referência</Label>
                    <Input
                      id="ponto_referencia_autor"
                      value={autor.ponto_referencia_autor}
                      onChange={(e) => handleAutorChange('ponto_referencia_autor', e.target.value)}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="testemunha" className="mt-4">
            <Card className="bg-white/95">
              <CardHeader>
                <CardTitle className="text-blue-900">Dados da Testemunha (Opcional)</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center space-x-2 mb-4">
                  <input
                    type="checkbox"
                    id="tem_testemunha"
                    checked={testemunha.tem_testemunha}
                    onChange={(e) => handleTestemunhaChange('tem_testemunha', e.target.checked)}
                    className="w-4 h-4"
                  />
                  <Label htmlFor="tem_testemunha" className="cursor-pointer text-blue-900">
                    Incluir dados de testemunha
                  </Label>
                </div>

                {testemunha.tem_testemunha && (
                  <>
                    <div>
                      <Label htmlFor="nome_testemunha" className="text-blue-900">Nome Completo *</Label>
                      <Input
                        id="nome_testemunha"
                        value={testemunha.nome_testemunha}
                        onChange={(e) => handleTestemunhaChange('nome_testemunha', e.target.value)}
                        className={errors.nome_testemunha ? 'border-red-500' : ''}
                      />
                      {errors.nome_testemunha && <p className="text-red-500 text-sm mt-1">{errors.nome_testemunha}</p>}
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="cpf_testemunha" className="text-blue-900">CPF *</Label>
                        <Input
                          id="cpf_testemunha"
                          value={testemunha.cpf_testemunha}
                          onChange={(e) => handleTestemunhaChange('cpf_testemunha', e.target.value)}
                          placeholder="000.000.000-00"
                          className={errors.cpf_testemunha ? 'border-red-500' : ''}
                        />
                        {errors.cpf_testemunha && <p className="text-red-500 text-sm mt-1">{errors.cpf_testemunha}</p>}
                      </div>

                      <div>
                        <Label htmlFor="telefone_testemunha" className="text-blue-900">Telefone Celular *</Label>
                        <Input
                          id="telefone_testemunha"
                          value={testemunha.telefone_testemunha}
                          onChange={(e) => handleTestemunhaChange('telefone_testemunha', e.target.value)}
                          placeholder="(00)00000-0000"
                          className={errors.telefone_testemunha ? 'border-red-500' : ''}
                        />
                        {errors.telefone_testemunha && <p className="text-red-500 text-sm mt-1">{errors.telefone_testemunha}</p>}
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="naturalidade_testemunha" className="text-blue-900">Naturalidade</Label>
                        <Input
                          id="naturalidade_testemunha"
                          value={testemunha.naturalidade_testemunha}
                          onChange={(e) => handleTestemunhaChange('naturalidade_testemunha', e.target.value)}
                        />
                      </div>

                      <div>
                        <Label htmlFor="nacionalidade_testemunha" className="text-blue-900">Nacionalidade</Label>
                        <Input
                          id="nacionalidade_testemunha"
                          value={testemunha.nacionalidade_testemunha}
                          onChange={(e) => handleTestemunhaChange('nacionalidade_testemunha', e.target.value)}
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="sexo_testemunha" className="text-blue-900">Sexo</Label>
                        <Input
                          id="sexo_testemunha"
                          value={testemunha.sexo_testemunha}
                          onChange={(e) => handleTestemunhaChange('sexo_testemunha', e.target.value)}
                        />
                      </div>

                      <div>
                        <Label htmlFor="data_nascimento_testemunha" className="text-blue-900">Data de Nascimento</Label>
                        <Input
                          id="data_nascimento_testemunha"
                          type="date"
                          value={testemunha.data_nascimento_testemunha}
                          onChange={(e) => handleTestemunhaChange('data_nascimento_testemunha', e.target.value)}
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="estado_civil_testemunha" className="text-blue-900">Estado Civil</Label>
                        <Input
                          id="estado_civil_testemunha"
                          value={testemunha.estado_civil_testemunha}
                          onChange={(e) => handleTestemunhaChange('estado_civil_testemunha', e.target.value)}
                        />
                      </div>

                      <div>
                        <Label htmlFor="profissao_testemunha" className="text-blue-900">Profissão</Label>
                        <Input
                          id="profissao_testemunha"
                          value={testemunha.profissao_testemunha}
                          onChange={(e) => handleTestemunhaChange('profissao_testemunha', e.target.value)}
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                      <div>
                        <Label htmlFor="escolaridade_testemunha" className="text-blue-900">Escolaridade</Label>
                        <Input
                          id="escolaridade_testemunha"
                          value={testemunha.escolaridade_testemunha}
                          onChange={(e) => handleTestemunhaChange('escolaridade_testemunha', e.target.value)}
                        />
                      </div>

                      <div>
                        <Label htmlFor="etnia_testemunha" className="text-blue-900">Etnia</Label>
                        <Input
                          id="etnia_testemunha"
                          value={testemunha.etnia_testemunha}
                          onChange={(e) => handleTestemunhaChange('etnia_testemunha', e.target.value)}
                        />
                      </div>

                      <div>
                        <Label htmlFor="identidade_genero_testemunha" className="text-blue-900">Identidade de Gênero</Label>
                        <Input
                          id="identidade_genero_testemunha"
                          value={testemunha.identidade_genero_testemunha}
                          onChange={(e) => handleTestemunhaChange('identidade_genero_testemunha', e.target.value)}
                        />
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="orientacao_sexual_testemunha" className="text-blue-900">Orientação Sexual</Label>
                      <Input
                        id="orientacao_sexual_testemunha"
                        value={testemunha.orientacao_sexual_testemunha}
                        onChange={(e) => handleTestemunhaChange('orientacao_sexual_testemunha', e.target.value)}
                      />
                    </div>

                    <div className="border-t pt-4 mt-4">
                      <h3 className="font-semibold mb-3 text-blue-900">Endereço Residencial</h3>
                      
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-4">
                        <div className="sm:col-span-2">
                          <Label htmlFor="logradouro_testemunha" className="text-blue-900">Logradouro</Label>
                          <Input
                            id="logradouro_testemunha"
                            value={testemunha.logradouro_testemunha}
                            onChange={(e) => handleTestemunhaChange('logradouro_testemunha', e.target.value)}
                          />
                        </div>

                        <div>
                          <Label htmlFor="numero_endereco_testemunha" className="text-blue-900">Número</Label>
                          <Input
                            id="numero_endereco_testemunha"
                            value={testemunha.numero_endereco_testemunha}
                            onChange={(e) => handleTestemunhaChange('numero_endereco_testemunha', e.target.value)}
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="bairro_testemunha" className="text-blue-900">Bairro</Label>
                          <Input
                            id="bairro_testemunha"
                            value={testemunha.bairro_testemunha}
                            onChange={(e) => handleTestemunhaChange('bairro_testemunha', e.target.value)}
                          />
                        </div>

                        <div>
                          <Label htmlFor="municipio_testemunha" className="text-blue-900">Município</Label>
                          <Input
                            id="municipio_testemunha"
                            value={testemunha.municipio_testemunha}
                            onChange={(e) => handleTestemunhaChange('municipio_testemunha', e.target.value)}
                          />
                        </div>
                      </div>

                      <div className="mt-4">
                        <Label htmlFor="ponto_referencia_testemunha" className="text-blue-900">Ponto de Referência</Label>
                        <Input
                          id="ponto_referencia_testemunha"
                          value={testemunha.ponto_referencia_testemunha}
                          onChange={(e) => handleTestemunhaChange('ponto_referencia_testemunha', e.target.value)}
                        />
                      </div>
                    </div>
                  </>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        <div className="mt-6 mb-8">
          <Button
            onClick={handleContinue}
            className="w-full min-h-[56px] bg-yellow-400 hover:bg-yellow-500 text-blue-900 font-bold text-lg sm:text-xl touch-manipulation"
          >
            Continuar
            <ArrowRight className="w-5 h-5 ml-2" />
          </Button>
        </div>
      </div>
    </div>
  );
}