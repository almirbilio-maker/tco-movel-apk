import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Plus, Trash2, Edit2, Search } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import ModalInfracao from '../components/infraccoes/ModalInfracao';
import ConfirmacaoExclusaoInfracao from '../components/infraccoes/ConfirmacaoExclusaoInfracao';

export default function GerenciarInfracoes() {
  const queryClient = useQueryClient();
  const [searchTerm, setSearchTerm] = useState('');
  const [modalAberto, setModalAberto] = useState(false);
  const [infraçãoEditando, setInfraçãoEditando] = useState(null);
  const [infraçãoParaExcluir, setInfraçãoParaExcluir] = useState(null);

  const { data: infrações = [], isLoading } = useQuery({
    queryKey: ['infracoes'],
    queryFn: () => base44.entities.InfracaoPenal.list()
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.InfracaoPenal.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['infracoes'] });
      setModalAberto(false);
      setInfraçãoEditando(null);
    }
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.InfracaoPenal.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['infracoes'] });
      setModalAberto(false);
      setInfraçãoEditando(null);
    }
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.InfracaoPenal.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['infracoes'] });
      setInfraçãoParaExcluir(null);
    }
  });

  const handleSalvar = (dados) => {
    if (infraçãoEditando) {
      updateMutation.mutate({ id: infraçãoEditando.id, data: dados });
    } else {
      createMutation.mutate(dados);
    }
  };

  const handleEditar = (infração) => {
    setInfraçãoEditando(infração);
    setModalAberto(true);
  };

  const handleNova = () => {
    setInfraçãoEditando(null);
    setModalAberto(true);
  };

  const handleFecharModal = () => {
    setModalAberto(false);
    setInfraçãoEditando(null);
  };

  const infraçõesFiltradas = infrações.filter((inf) =>
    inf.descricao.toLowerCase().includes(searchTerm.toLowerCase()) ||
    inf.artigo.toLowerCase().includes(searchTerm.toLowerCase()) ||
    inf.diploma_legal.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="min-h-screen pb-24">
      <div className="bg-blue-950 px-4 pt-4 pb-4">
        <h2 className="text-lg font-bold text-yellow-400 mb-3">Gerenciar Infrações Penais</h2>
        
        <div className="relative mb-3">
          <Search className="absolute left-3 top-2.5 w-5 h-5 text-blue-400" />
          <Input
            type="text"
            placeholder="Buscar por descrição, artigo ou lei..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="bg-blue-800 border-blue-600 text-white placeholder:text-blue-400 pl-10"
          />
        </div>

        <div className="text-xs text-blue-200">
          {infraçõesFiltradas.length} infração(ões) encontrada(s)
        </div>
      </div>

      <div className="p-4 space-y-3">
        {isLoading ? (
          <div className="text-center py-8 text-yellow-100">Carregando...</div>
        ) : infraçõesFiltradas.length > 0 ? (
          infraçõesFiltradas.map((infração) => (
            <Card key={infração.id} className="bg-white/95 border-l-4 border-l-blue-600">
              <CardContent className="p-4">
                <div className="flex items-start justify-between mb-2">
                  <div className="flex-1">
                    <h3 className="font-bold text-blue-900">{infração.descricao}</h3>
                    <div className="text-xs text-gray-600 mt-1">
                      <p>{infração.diploma_legal} - Art. {infração.artigo}</p>
                    </div>
                  </div>
                  <div className="flex gap-2 ml-2">
                    <Button
                      onClick={() => handleEditar(infração)}
                      variant="ghost"
                      size="sm"
                      className="text-blue-600 hover:bg-blue-100"
                    >
                      <Edit2 className="w-4 h-4" />
                    </Button>
                    <Button
                      onClick={() => setInfraçãoParaExcluir(infração)}
                      variant="ghost"
                      size="sm"
                      className="text-red-600 hover:bg-red-100"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>

                <div className="text-sm text-gray-700 mt-2 space-y-1">
                  <p>
                    <span className="font-semibold">Pena:</span> {infração.pena_minima} a {infração.pena_maxima}
                  </p>
                  <p>
                    <span className="font-semibold">Classificação:</span> {infração.classificacao}
                  </p>
                  {infração.observacao && (
                    <p className="text-xs text-gray-600 italic">
                      <span className="font-semibold">Observação:</span> {infração.observacao}
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>
          ))
        ) : (
          <div className="text-center py-12 text-yellow-100">
            Nenhuma infração encontrada
          </div>
        )}
      </div>

      <Button
        onClick={handleNova}
        className="fixed bottom-6 right-6 w-14 h-14 rounded-full shadow-2xl bg-yellow-400 hover:bg-yellow-500 text-blue-900 p-0 z-30"
      >
        <Plus className="w-6 h-6" />
      </Button>

      <ModalInfracao
        open={modalAberto}
        onOpenChange={handleFecharModal}
        infração={infraçãoEditando}
        onSalvar={handleSalvar}
        isLoading={createMutation.isPending || updateMutation.isPending}
      />

      <ConfirmacaoExclusaoInfracao
        open={!!infraçãoParaExcluir}
        onOpenChange={(open) => !open && setInfraçãoParaExcluir(null)}
        onConfirm={() => deleteMutation.mutate(infraçãoParaExcluir.id)}
        descricao={infraçãoParaExcluir?.descricao}
      />
    </div>
  );
}