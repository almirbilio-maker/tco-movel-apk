import React, { useState } from 'react';
import { Menu, X, User, FileText, Settings, LogOut } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';
import { createPageUrl } from './utils';
import { Button } from '@/components/ui/button';

export default function Layout({ children, currentPageName }) {
  const [drawerOpen, setDrawerOpen] = useState(false);
  const location = useLocation();

  const menuItems = [
    { label: 'Histórico de Ocorrências', icon: FileText, page: 'Home' },
    { label: 'Gerenciar Infrações', icon: FileText, page: 'GerenciarInfracoes' },
    { label: 'Dados do Operador', icon: User, page: 'DadosOperador' },
    { label: 'Configurações', icon: Settings, page: 'Configuracoes' },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 via-blue-800 to-blue-900">
      {/* Header */}
      <div className="bg-blue-950 border-b border-blue-700 px-4 py-3 flex items-center justify-between shadow-lg">
        <button
          onClick={() => setDrawerOpen(true)}
          className="p-2 hover:bg-blue-800 rounded-lg transition-colors"
        >
          <Menu className="w-6 h-6 text-yellow-400" />
        </button>
        <div className="flex items-center gap-3">
          <img 
            src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/699f5d061f02ec2b4c492957/4c24c7c5d_TCOapp2.png" 
            alt="TCO Logo" 
            className="w-10 h-10 rounded-lg"
          />
          <span className="text-yellow-400 text-2xl font-light">|</span>
          <h1 className="text-xl font-bold text-yellow-400">TCO Móvel</h1>
        </div>
        <div className="w-10" />
      </div>

      {/* Drawer Overlay */}
      {drawerOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-40"
          onClick={() => setDrawerOpen(false)}
        />
      )}

      {/* Drawer */}
      <div
        className={`fixed top-0 left-0 h-full w-72 bg-white shadow-2xl z-50 transform transition-transform duration-300 ${
          drawerOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="p-4 bg-blue-950 flex items-center justify-between">
          <h2 className="text-lg font-bold text-yellow-400">Menu</h2>
          <button
            onClick={() => setDrawerOpen(false)}
            className="p-2 hover:bg-blue-800 rounded-lg transition-colors"
          >
            <X className="w-5 h-5 text-yellow-400" />
          </button>
        </div>

        <div className="p-4">
          <nav className="space-y-2">
            {menuItems.map((item) => {
              const Icon = item.icon;
              return (
                <Link
                  key={item.page}
                  to={createPageUrl(item.page)}
                  onClick={() => setDrawerOpen(false)}
                  className="flex items-center gap-3 p-3 rounded-lg hover:bg-blue-50 transition-colors text-gray-700 hover:text-blue-900"
                >
                  <Icon className="w-5 h-5" />
                  <span className="font-medium">{item.label}</span>
                </Link>
              );
            })}
          </nav>
        </div>
      </div>

      {/* Main Content */}
      <main>{children}</main>
    </div>
  );
}